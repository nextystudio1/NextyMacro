package com.nextystudio.nextymacro

data class Condition(
    val id: Long,
    val name: String,
    val imagePath: String,
    val threshold: Int = 88
)

data class MacroAction(
    val id: Long,
    val name: String,
    val x: Int,
    val y: Int,
    val conditionId: Long? = null,
    val delayMs: Long = 0
)
