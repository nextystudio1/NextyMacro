# Nexty Macro v15

- Preserves the working canonical tap path from v14.
- Adds an explicit 🗑 HAPUS button for every action.
- Improves image-condition matching by scanning at 2px positions and denser template sampling, reducing false negatives when the detected image is not aligned to an 8px grid.
- Condition remains a gate for the same action.
