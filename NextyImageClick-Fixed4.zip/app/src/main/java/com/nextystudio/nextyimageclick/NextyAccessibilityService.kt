package com.nextystudio.nextyimageclick

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.graphics.Bitmap
import android.graphics.Path
import android.graphics.PointF
import android.graphics.RectF
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.view.*
import android.widget.*
import android.content.Intent
import java.util.concurrent.Executors
import kotlin.math.roundToInt

class NextyAccessibilityService : AccessibilityService() {
    companion object {
        const val ACTION_SHOW = "nexty.show"
        const val ACTION_START = "nexty.start"
        const val ACTION_STOP = "nexty.stop"
        private var instance: NextyAccessibilityService? = null
        fun get(): NextyAccessibilityService? = instance
    }

    private val main = Handler(Looper.getMainLooper())
    private val executor = Executors.newSingleThreadExecutor()
    private var panel: LinearLayout? = null
    private var detectorOn = false
    private var pickerOn = false
    private var regionPickerOn = false
    private var busy = false
    private var lastClick = 0L

    override fun onServiceConnected() { super.onServiceConnected(); instance = this }
    override fun onDestroy() { instance = null; executor.shutdownNow(); removeOverlay(); super.onDestroy() }
    override fun onAccessibilityEvent(event: android.view.accessibility.AccessibilityEvent?) {}
    override fun onInterrupt() {}

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_SHOW -> showPanel()
            ACTION_START -> startDetector()
            ACTION_STOP -> stopDetector()
        }
        return START_STICKY
    }

    fun showPanel() {
        main.post {
            if (panel != null) return@post
            val wm = getSystemService(WINDOW_SERVICE) as WindowManager
            val p = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                setPadding(14, 12, 14, 12)
                setBackgroundColor(0xEE1B1B1B.toInt())
            }
            val title = TextView(this).apply {
                text = "NEXTY • IMAGE DETECTION"
                textSize = 14f
                setTextColor(0xFFFFFFFF.toInt())
                setPadding(8, 4, 8, 8)
            }
            p.addView(title)

            val region = Button(this).apply {
                text = if (Settings.getRegion(this@NextyAccessibilityService) == null) "▣ AREA DETEKSI" else "▣ AREA: TERSIMPAN"
                setOnClickListener { startRegionPicker() }
            }
            val clickMode = Spinner(this).apply {
                adapter = ArrayAdapter(this@NextyAccessibilityService, android.R.layout.simple_spinner_dropdown_item,
                    arrayOf("Tap", "Double Tap", "Long Press"))
                setSelection(Settings.clickMode(this@NextyAccessibilityService))
                onItemSelectedListener = object : android.widget.AdapterView.OnItemSelectedListener {
                    override fun onItemSelected(parent: android.widget.AdapterView<*>?, view: View?, position: Int, id: Long) {
                        Settings.saveClickMode(this@NextyAccessibilityService, position)
                    }
                    override fun onNothingSelected(parent: android.widget.AdapterView<*>?) {}
                }
            }
            val image = Switch(this).apply {
                text = "🖼 DETECTION"
                setTextColor(0xFFFFFFFF.toInt())
                isChecked = detectorOn
                setOnCheckedChangeListener { _, checked -> if (checked) startDetector() else stopDetector() }
            }
            val start = Button(this).apply { text = "▶ START"; setOnClickListener { startDetector() } }
            val stop = Button(this).apply { text = "■ STOP"; setOnClickListener { stopDetector() } }
            val close = Button(this).apply { text = "× TUTUP"; setOnClickListener { removeOverlay() } }

            p.addView(region)
            p.addView(clickMode)
            p.addView(image)
            p.addView(start)
            p.addView(stop)
            p.addView(close)

            val lp = WindowManager.LayoutParams(
                250, WindowManager.LayoutParams.WRAP_CONTENT,
                WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
                android.graphics.PixelFormat.TRANSLUCENT
            ).apply { gravity = Gravity.TOP or Gravity.END; x = 12; y = 80 }

            title.setOnTouchListener(object : View.OnTouchListener {
                var downX = 0f; var downY = 0f; var startX = 0; var startY = 0
                override fun onTouch(v: View, e: MotionEvent): Boolean {
                    when (e.action) {
                        MotionEvent.ACTION_DOWN -> { downX = e.rawX; downY = e.rawY; startX = lp.x; startY = lp.y; return true }
                        MotionEvent.ACTION_MOVE -> { lp.x = startX + (e.rawX - downX).roundToInt(); lp.y = startY + (e.rawY - downY).roundToInt(); wm.updateViewLayout(p, lp); return true }
                        MotionEvent.ACTION_UP -> return true
                    }
                    return false
                }
            })
            wm.addView(p, lp)
            panel = p
        }
    }

    private fun startRegionPicker() {
        if (regionPickerOn) return
        regionPickerOn = true
        val wm = getSystemService(WINDOW_SERVICE) as WindowManager
        val overlay = FrameLayout(this).apply { setBackgroundColor(0x33000000) }
        val hint = TextView(this).apply {
            text = "DRAG untuk memilih AREA DETEKSI"
            textSize = 20f
            gravity = Gravity.CENTER
            setTextColor(0xFFFFFFFF.toInt())
            setBackgroundColor(0xAA000000.toInt())
        }
        overlay.addView(hint, FrameLayout.LayoutParams(-2, -2, Gravity.CENTER))
        var sx = 0f; var sy = 0f
        overlay.setOnTouchListener { _, e ->
            when (e.action) {
                MotionEvent.ACTION_DOWN -> { sx = e.rawX; sy = e.rawY; hint.visibility = View.INVISIBLE; true }
                MotionEvent.ACTION_UP -> {
                    val r = RectF(minOf(sx, e.rawX), minOf(sy, e.rawY), maxOf(sx, e.rawX), maxOf(sy, e.rawY))
                    if (r.width() >= 20f && r.height() >= 20f) Settings.saveRegion(this, r)
                    try { wm.removeView(overlay) } catch (_: Throwable) {}
                    regionPickerOn = false
                    Toast.makeText(this, if (r.width() >= 20f && r.height() >= 20f) "Area deteksi tersimpan" else "Area terlalu kecil", Toast.LENGTH_SHORT).show()
                    true
                }
                else -> true
            }
        }
        val lp = WindowManager.LayoutParams(-1, -1, WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY, WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE, android.graphics.PixelFormat.TRANSLUCENT)
        wm.addView(overlay, lp)
    }

    private fun startPicker() {
        if (pickerOn) return
        pickerOn = true
        val wm = getSystemService(WINDOW_SERVICE) as WindowManager
        val pick = FrameLayout(this).apply {
            setBackgroundColor(0x22000000)
            val label = TextView(this@NextyAccessibilityService).apply {
                text = "TAP POSISI KLIK\n(ketuk sekali)"
                textSize = 24f
                gravity = Gravity.CENTER
                setTextColor(0xFFFFFFFF.toInt())
                setBackgroundColor(0xAA000000.toInt())
                setPadding(30, 20, 30, 20)
            }
            addView(label, FrameLayout.LayoutParams(-2, -2, Gravity.CENTER))
            setOnTouchListener { _, e ->
                if (e.action == MotionEvent.ACTION_UP) {
                    Settings.savePoint(this@NextyAccessibilityService, PointF(e.rawX, e.rawY))
                    wm.removeView(this)
                    pickerOn = false
                    Toast.makeText(this@NextyAccessibilityService, "Titik klik tersimpan", Toast.LENGTH_SHORT).show()
                    true
                } else true
            }
        }
        val lp = WindowManager.LayoutParams(-1, -1, WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY, WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE, android.graphics.PixelFormat.TRANSLUCENT)
        wm.addView(pick, lp)
    }

    private fun startDetector() {
        if (detectorOn) return
        if (!Settings.targetExists(this)) { Toast.makeText(this, "Pilih gambar target dulu.", Toast.LENGTH_SHORT).show(); return }
        detectorOn = true
        scheduleCapture()
    }

    private fun stopDetector() { detectorOn = false; busy = false }

    private fun scheduleCapture() {
        if (!detectorOn) return
        takeShot()
        main.postDelayed({ scheduleCapture() }, Settings.interval(this))
    }

    private fun takeShot() {
        if (busy || Build.VERSION.SDK_INT < 30) return
        busy = true
        takeScreenshot(0, executor, object : TakeScreenshotCallback {
            override fun onSuccess(result: ScreenshotResult) {
                try {
                    val hw = result.hardwareBuffer
                    val full = Bitmap.wrapHardwareBuffer(hw, result.colorSpace)
                    hw.close()
                    if (full == null) { busy = false; return }
                    val screen = full.copy(Bitmap.Config.ARGB_8888, false)
                    full.recycle()
                    executor.execute {
                        try {
                            val target = BitmapFactoryCompat.load(this@NextyAccessibilityService)
                            if (target == null) { screen.recycle(); busy = false; return@execute }
                            val region = Settings.getRegion(this@NextyAccessibilityService)
                            val left = (region?.left ?: 0f).toInt().coerceIn(0, screen.width - 1)
                            val top = (region?.top ?: 0f).toInt().coerceIn(0, screen.height - 1)
                            val right = (region?.right ?: screen.width.toFloat()).toInt().coerceIn(left + 1, screen.width)
                            val bottom = (region?.bottom ?: screen.height.toFloat()).toInt().coerceIn(top + 1, screen.height)
                            val crop = Bitmap.createBitmap(screen, left, top, right - left, bottom - top)
                            val match = ImageMatcher.find(crop, target, Settings.threshold(this@NextyAccessibilityService))
                            crop.recycle(); target.recycle(); screen.recycle()
                            if (match.found) {
                                val now = System.currentTimeMillis()
                                if (now - lastClick >= Settings.cooldown(this@NextyAccessibilityService)) {
                                    lastClick = now
                                    val x = match.x + left + Settings.offsetX(this@NextyAccessibilityService)
                                    val y = match.y + top + Settings.offsetY(this@NextyAccessibilityService)
                                    main.postDelayed({ performClick(PointF(x, y)) }, Settings.delay(this@NextyAccessibilityService))
                                }
                            }
                        } catch (_: Throwable) {
                        } finally { busy = false }
                    }
                } catch (_: Throwable) { busy = false }
            }
            override fun onFailure(errorCode: Int) { busy = false }
        })
    }

    private fun performClick(p: PointF) {
        val duration = when (Settings.clickMode(this)) { 2 -> 650L; else -> 80L }
        val path = Path().apply { moveTo(p.x, p.y) }
        val gesture = GestureDescription.Builder().addStroke(GestureDescription.StrokeDescription(path, 0, duration)).build()
        dispatchGesture(gesture, if (Settings.clickMode(this) == 1) object : GestureResultCallback() {
            override fun onCompleted(gestureDescription: GestureDescription?) { main.postDelayed({ performTapOnly(p) }, 90) }
        } else null, null)
    }

    private fun performTapOnly(p: PointF) {
        val path = Path().apply { moveTo(p.x, p.y) }
        val gesture = GestureDescription.Builder().addStroke(GestureDescription.StrokeDescription(path, 0, 80)).build()
        dispatchGesture(gesture, null, null)
    }

    private fun removeOverlay() {
        main.post {
            val wm = getSystemService(WINDOW_SERVICE) as WindowManager
            panel?.let { try { wm.removeView(it) } catch (_: Throwable) {} }
            panel = null
            stopDetector()
        }
    }
}

private object BitmapFactoryCompat {
    fun load(c: android.content.Context): Bitmap? = android.graphics.BitmapFactory.decodeFile(Settings.targetPath(c))
}
