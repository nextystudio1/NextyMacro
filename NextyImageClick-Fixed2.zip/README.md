# Nexty Image Click

Landscape game-oriented Android auto clicker.

Core flow:
1. Pick a target image from the phone.
2. Enable Accessibility.
3. Show the floating panel over the game.
4. Tap "ARAH KLIK" and tap the desired click coordinate.
5. Turn "GAMBAR" on or press START.
6. The service screenshots the screen, searches for the target image, and taps the saved coordinate when the match is found.

Notes:
- Android 11+ only (API 30+).
- The matcher is dependency-free and optimized for small targets; exact visual scale is expected.
- This is a first image-trigger version, not a full Macrorify clone.
