package com.nextystudio.nextymacro;

import android.accessibilityservice.AccessibilityService;
import android.accessibilityservice.GestureDescription;
import android.graphics.Path;
import android.os.Bundle;
import android.view.accessibility.AccessibilityEvent;
import android.view.accessibility.AccessibilityNodeInfo;

public class NextyAccessibilityService extends AccessibilityService {
    public static NextyAccessibilityService instance;
    @Override public void onServiceConnected(){ super.onServiceConnected(); instance=this; }
    @Override public void onAccessibilityEvent(AccessibilityEvent event){}
    @Override public void onInterrupt(){ if(instance==this) instance=null; }
    public void tap(float x,float y,long duration){ if(android.os.Build.VERSION.SDK_INT<24)return; Path p=new Path();p.moveTo(x,y);GestureDescription.StrokeDescription s=new GestureDescription.StrokeDescription(p,0,Math.max(1,duration));dispatchGesture(new GestureDescription.Builder().addStroke(s).build(),null,null); }
    public void swipe(float x1,float y1,float x2,float y2,long duration){ if(android.os.Build.VERSION.SDK_INT<24)return; Path p=new Path();p.moveTo(x1,y1);p.lineTo(x2,y2);GestureDescription.StrokeDescription s=new GestureDescription.StrokeDescription(p,0,Math.max(10,duration));dispatchGesture(new GestureDescription.Builder().addStroke(s).build(),null,null); }
    public void backKey(){performGlobalAction(GLOBAL_ACTION_BACK);}
    public void homeKey(){performGlobalAction(GLOBAL_ACTION_HOME);}
    public void recentsKey(){performGlobalAction(GLOBAL_ACTION_RECENTS);}
    public void inputText(String text){ AccessibilityNodeInfo root=getRootInActiveWindow(); if(root==null)return; Bundle b=new Bundle();b.putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE,text);root.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT,b); }
}
