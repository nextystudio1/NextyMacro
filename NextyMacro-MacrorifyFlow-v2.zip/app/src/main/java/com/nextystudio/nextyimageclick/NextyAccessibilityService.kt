package com.nextystudio.nextyimageclick

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.graphics.Bitmap
import android.graphics.Path
import android.graphics.PointF
import android.graphics.RectF
import android.content.Intent
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.view.*
import android.widget.*
import java.util.concurrent.Executors
import kotlin.math.roundToInt

class NextyAccessibilityService : AccessibilityService() {
    companion object {
        const val ACTION_SHOW = "nexty.show"
        const val ACTION_START = "nexty.start"
        const val ACTION_STOP = "nexty.stop"
        private var instance: NextyAccessibilityService? = null
        fun get(): NextyAccessibilityService? = instance
    }

    private val main = Handler(Looper.getMainLooper())
    private val executor = Executors.newSingleThreadExecutor()
    private var panel: LinearLayout? = null
    private var running = false
    private var busy = false
    private var currentStep = 0
    private var completedLoops = 0
    private var detectedPoint: PointF? = null
    private var panelStatus: TextView? = null

    override fun onServiceConnected() { super.onServiceConnected(); instance = this }
    override fun onDestroy() { instance = null; executor.shutdownNow(); removeOverlay(); super.onDestroy() }
    override fun onAccessibilityEvent(event: android.view.accessibility.AccessibilityEvent?) {}
    override fun onInterrupt() {}

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_SHOW -> showPanel()
            ACTION_START -> startMacro()
            ACTION_STOP -> stopMacro()
        }
        return START_STICKY
    }

    fun showPanel() {
        main.post {
            if (panel != null) return@post
            val wm = getSystemService(WINDOW_SERVICE) as WindowManager
            val p = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                setPadding(14, 12, 14, 12)
                setBackgroundColor(0xEE1B1B1B.toInt())
            }
            val title = TextView(this).apply {
                text = "NEXTY • MACRO"
                textSize = 15f
                setTextColor(0xFFFFFFFF.toInt())
                setPadding(8, 4, 8, 8)
            }
            panelStatus = TextView(this).apply { text = statusText(); textSize = 12f; setTextColor(0xFFFFFFFF.toInt()); setPadding(8, 2, 8, 8) }
            val start = Button(this).apply { text = "▶ START MACRO"; setOnClickListener { startMacro() } }
            val stop = Button(this).apply { text = "■ STOP"; setOnClickListener { stopMacro() } }
            val close = Button(this).apply { text = "× TUTUP"; setOnClickListener { removeOverlay() } }
            p.addView(title); p.addView(panelStatus); p.addView(start); p.addView(stop); p.addView(close)
            val lp = WindowManager.LayoutParams(270, WindowManager.LayoutParams.WRAP_CONTENT, WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY, WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE, android.graphics.PixelFormat.TRANSLUCENT).apply { gravity = Gravity.TOP or Gravity.END; x = 12; y = 80 }
            title.setOnTouchListener(object : View.OnTouchListener {
                var downX = 0f; var downY = 0f; var startX = 0; var startY = 0
                override fun onTouch(v: View, e: MotionEvent): Boolean {
                    when (e.action) {
                        MotionEvent.ACTION_DOWN -> { downX = e.rawX; downY = e.rawY; startX = lp.x; startY = lp.y; return true }
                        MotionEvent.ACTION_MOVE -> { lp.x = startX + (e.rawX - downX).roundToInt(); lp.y = startY + (e.rawY - downY).roundToInt(); wm.updateViewLayout(p, lp); return true }
                        MotionEvent.ACTION_UP -> return true
                    }; return false
                }
            })
            wm.addView(p, lp); panel = p
        }
    }

    private fun statusText(): String {
        val n = MacroStore.getSteps(this).size
        return if (running) "BERJALAN • tindakan ${currentStep + 1}/$n • loop ${completedLoops + 1}" else "STOP • $n tindakan tersimpan"
    }

    private fun updatePanel() { main.post { panelStatus?.text = statusText() } }

    fun startRegionPicker() {
        val wm = getSystemService(WINDOW_SERVICE) as WindowManager
        val overlay = FrameLayout(this).apply { setBackgroundColor(0x33000000) }
        val hint = TextView(this).apply { text = "DRAG untuk memilih POTONGAN\nLepaskan untuk menyimpan"; textSize = 20f; gravity = Gravity.CENTER; setTextColor(0xFFFFFFFF.toInt()); setBackgroundColor(0xAA000000.toInt()); setPadding(30, 20, 30, 20) }
        overlay.addView(hint, FrameLayout.LayoutParams(-2, -2, Gravity.CENTER))
        var sx = 0f; var sy = 0f
        overlay.setOnTouchListener { _, e ->
            when (e.action) {
                MotionEvent.ACTION_DOWN -> { sx = e.rawX; sy = e.rawY; hint.visibility = View.INVISIBLE; true }
                MotionEvent.ACTION_UP -> {
                    val r = RectF(minOf(sx, e.rawX), minOf(sy, e.rawY), maxOf(sx, e.rawX), maxOf(sy, e.rawY))
                    if (r.width() >= 20f && r.height() >= 20f) Settings.saveRegion(this, r)
                    try { wm.removeView(overlay) } catch (_: Throwable) {}
                    Toast.makeText(this, if (r.width() >= 20f && r.height() >= 20f) "Potongan tersimpan" else "Potongan terlalu kecil", Toast.LENGTH_SHORT).show(); true
                }
                else -> true
            }
        }
        wm.addView(overlay, WindowManager.LayoutParams(-1, -1, WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY, WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE, android.graphics.PixelFormat.TRANSLUCENT))
    }

    fun startCoordinatePicker(onPicked: (PointF) -> Unit) {
        val wm = getSystemService(WINDOW_SERVICE) as WindowManager
        val pick = FrameLayout(this).apply { setBackgroundColor(0x22000000) }
        val label = TextView(this).apply { text = "TAP POSISI\n(ketuk sekali)"; textSize = 24f; gravity = Gravity.CENTER; setTextColor(0xFFFFFFFF.toInt()); setBackgroundColor(0xAA000000.toInt()); setPadding(30, 20, 30, 20) }
        pick.addView(label, FrameLayout.LayoutParams(-2, -2, Gravity.CENTER))
        pick.setOnTouchListener { _, e ->
            if (e.action == MotionEvent.ACTION_UP) {
                val p = PointF(e.rawX, e.rawY); try { wm.removeView(pick) } catch (_: Throwable) {}; onPicked(p); true
            } else true
        }
        wm.addView(pick, WindowManager.LayoutParams(-1, -1, WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY, WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE, android.graphics.PixelFormat.TRANSLUCENT))
    }

    fun startMacro() {
        if (running) return
        val steps = MacroStore.getSteps(this)
        if (steps.isEmpty()) { Toast.makeText(this, "Tambahkan tindakan dulu.", Toast.LENGTH_SHORT).show(); return }
        if (!Settings.targetExists(this) && steps.any { it.type == StepType.CONDITION_IMAGE || it.type == StepType.CLICK_DETECTED }) {
            Toast.makeText(this, "Pilih gambar target dulu.", Toast.LENGTH_SHORT).show(); return
        }
        if (Build.VERSION.SDK_INT < 30) { Toast.makeText(this, "Android 11+ diperlukan untuk screenshot deteksi.", Toast.LENGTH_SHORT).show(); return }
        running = true; busy = false; currentStep = 0; completedLoops = 0; detectedPoint = null
        updatePanel(); executeCurrentStep()
    }

    fun stopMacro() { running = false; busy = false; main.removeCallbacksAndMessages(null); updatePanel(); Toast.makeText(this, "Macro dihentikan", Toast.LENGTH_SHORT).show() }

    private fun executeCurrentStep() {
        if (!running) return
        val steps = MacroStore.getSteps(this)
        if (steps.isEmpty()) { stopMacro(); return }
        if (currentStep >= steps.size) {
            completedLoops++
            val mode = MacroStore.loopMode(this)
            if (mode == 0 || (mode == 1 && completedLoops >= MacroStore.loopCount(this))) {
                running = false
                updatePanel()
                Toast.makeText(this, "Macro selesai: $completedLoops putaran", Toast.LENGTH_SHORT).show()
                return
            }
            currentStep = 0
            detectedPoint = null
            updatePanel()
            main.post { executeCurrentStep() }
            return
        }

        updatePanel()
        val step = steps[currentStep]
        when (step.type) {
            StepType.CONDITION_IMAGE -> waitForImage()
            StepType.CLICK_DETECTED -> {
                val p = detectedPoint
                if (p == null) {
                    currentStep++
                    executeCurrentStep()
                } else {
                    detectedPoint = null
                    performClick(PointF(p.x + Settings.offsetX(this), p.y + Settings.offsetY(this))) {
                        currentStep++
                        executeCurrentStep()
                    }
                }
            }
            StepType.DELAY -> {
                main.postDelayed({
                    if (running) {
                        currentStep++
                        executeCurrentStep()
                    }
                }, step.delayMs.coerceAtLeast(0L))
            }
            StepType.CLICK_COORD -> {
                performClick(PointF(step.x, step.y)) {
                    currentStep++
                    executeCurrentStep()
                }
            }
        }
    }

    private fun waitForImage() {
        if (!running || busy) return
        busy = true
        takeScreenshot(0, executor, object : TakeScreenshotCallback {
            override fun onSuccess(result: ScreenshotResult) {
                try {
                    val hw = result.hardwareBuffer
                    val full = Bitmap.wrapHardwareBuffer(hw, result.colorSpace)
                    hw.close()
                    if (full == null) { retryCondition(); return }
                    val screen = full.copy(Bitmap.Config.ARGB_8888, false); full.recycle()
                    executor.execute {
                        var crop: Bitmap? = null; var target: Bitmap? = null
                        try {
                            target = BitmapFactoryCompat.load(this@NextyAccessibilityService)
                            if (target == null) { retryCondition(); return@execute }
                            val region = Settings.getRegion(this@NextyAccessibilityService)
                            val left = (region?.left ?: 0f).toInt().coerceIn(0, screen.width - 1)
                            val top = (region?.top ?: 0f).toInt().coerceIn(0, screen.height - 1)
                            val right = (region?.right ?: screen.width.toFloat()).toInt().coerceIn(left + 1, screen.width)
                            val bottom = (region?.bottom ?: screen.height.toFloat()).toInt().coerceIn(top + 1, screen.height)
                            crop = Bitmap.createBitmap(screen, left, top, right - left, bottom - top)
                            val match = ImageMatcher.find(crop!!, target!!, Settings.threshold(this@NextyAccessibilityService))
                            if (match.found) {
                                detectedPoint = PointF(match.x + left, match.y + top)
                                busy = false; currentStep++; main.post { executeCurrentStep() }
                            } else retryCondition()
                        } catch (_: Throwable) { retryCondition() }
                        finally { crop?.recycle(); target?.recycle(); screen.recycle() }
                    }
                } catch (_: Throwable) { retryCondition() }
            }
            override fun onFailure(errorCode: Int) { retryCondition() }
        })
    }

    private fun retryCondition() {
        busy = false
        if (running) main.postDelayed({ waitForImage() }, Settings.interval(this))
    }

    private fun performClick(p: PointF, done: () -> Unit) {
        val mode = Settings.clickMode(this)
        val duration = if (mode == 2) 650L else 70L
        val path = Path().apply { moveTo(p.x, p.y) }
        val gesture = GestureDescription.Builder().addStroke(GestureDescription.StrokeDescription(path, 0, duration)).build()
        dispatchGesture(gesture, object : GestureResultCallback() {
            override fun onCompleted(gestureDescription: GestureDescription?) {
                if (mode == 1) {
                    main.postDelayed({ performSingleTap(p, done) }, 90L)
                } else main.postDelayed(done, Settings.cooldown(this@NextyAccessibilityService).coerceAtLeast(0L))
            }
            override fun onCancelled(gestureDescription: GestureDescription?) { main.postDelayed(done, 100L) }
        }, null)
    }

    private fun performSingleTap(p: PointF, done: () -> Unit) {
        val path = Path().apply { moveTo(p.x, p.y) }
        val g = GestureDescription.Builder().addStroke(GestureDescription.StrokeDescription(path, 0, 70L)).build()
        dispatchGesture(g, object : GestureResultCallback() { override fun onCompleted(gd: GestureDescription?) { main.postDelayed(done, Settings.cooldown(this@NextyAccessibilityService).coerceAtLeast(0L)) }; override fun onCancelled(gd: GestureDescription?) { main.postDelayed(done, 100L) } }, null)
    }

    private fun removeOverlay() {
        main.post {
            stopMacro()
            val wm = getSystemService(WINDOW_SERVICE) as WindowManager
            panel?.let { try { wm.removeView(it) } catch (_: Throwable) {} }
            panel = null; panelStatus = null
        }
    }
}

private object BitmapFactoryCompat {
    fun load(c: android.content.Context): Bitmap? = android.graphics.BitmapFactory.decodeFile(Settings.targetPath(c))
}
