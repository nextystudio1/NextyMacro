NextyMacro v33 - Accessibility Stable 2
- Minimal accessibility event configuration.
- Synchronous safe overlay cleanup in service onDestroy.
- Keeps v32 macro/panel features unchanged.
