package com.nextystudio.nextyimageclick

import android.content.Context
import android.graphics.PointF
import android.graphics.RectF

object Settings {
    private const val PREF = "nexty"
    private const val TARGET = "target.png"
    private const val X = "click_x"
    private const val Y = "click_y"
    private const val THRESH = "threshold"
    private const val INTERVAL = "interval"
    private const val DELAY = "delay"
    private const val COOLDOWN = "cooldown"
    private const val CLICK_MODE = "click_mode"
    private const val OFFSET_X = "offset_x"
    private const val OFFSET_Y = "offset_y"
    private const val REGION_L = "region_l"
    private const val REGION_T = "region_t"
    private const val REGION_R = "region_r"
    private const val REGION_B = "region_b"

    private fun prefs(context: Context) = context.getSharedPreferences(PREF, 0)

    fun saveTarget(context: Context, bytes: ByteArray) {
        context.openFileOutput(TARGET, Context.MODE_PRIVATE).use { it.write(bytes) }
    }

    fun targetExists(context: Context) = context.getFileStreamPath(TARGET).exists()
    fun targetPath(context: Context) = context.getFileStreamPath(TARGET).absolutePath

    fun savePoint(context: Context, p: PointF) = prefs(context).edit()
        .putFloat(X, p.x).putFloat(Y, p.y).apply()

    fun getPoint(context: Context): PointF? {
        val p = prefs(context)
        if (!p.contains(X)) return null
        return PointF(p.getFloat(X, 0f), p.getFloat(Y, 0f))
    }

    fun saveThreshold(context: Context, v: Int) = prefs(context).edit().putInt(THRESH, v).apply()
    fun threshold(context: Context) = prefs(context).getInt(THRESH, 82)

    fun saveInterval(context: Context, v: Long) = prefs(context).edit().putLong(INTERVAL, v.coerceIn(100L, 3000L)).apply()
    fun interval(context: Context) = prefs(context).getLong(INTERVAL, 500L)

    fun saveDelay(context: Context, v: Long) = prefs(context).edit().putLong(DELAY, v.coerceIn(0L, 5000L)).apply()
    fun delay(context: Context) = prefs(context).getLong(DELAY, 0L)

    fun saveCooldown(context: Context, v: Long) = prefs(context).edit().putLong(COOLDOWN, v.coerceIn(0L, 10000L)).apply()
    fun cooldown(context: Context) = prefs(context).getLong(COOLDOWN, 700L)

    fun saveClickMode(context: Context, v: Int) = prefs(context).edit().putInt(CLICK_MODE, v.coerceIn(0, 2)).apply()
    fun clickMode(context: Context) = prefs(context).getInt(CLICK_MODE, 0)

    fun saveOffset(context: Context, x: Int, y: Int) = prefs(context).edit().putInt(OFFSET_X, x).putInt(OFFSET_Y, y).apply()
    fun offsetX(context: Context) = prefs(context).getInt(OFFSET_X, 0)
    fun offsetY(context: Context) = prefs(context).getInt(OFFSET_Y, 0)

    fun saveRegion(context: Context, r: RectF) = prefs(context).edit()
        .putFloat(REGION_L, r.left).putFloat(REGION_T, r.top)
        .putFloat(REGION_R, r.right).putFloat(REGION_B, r.bottom).apply()

    fun getRegion(context: Context): RectF? {
        val p = prefs(context)
        if (!p.contains(REGION_L)) return null
        return RectF(p.getFloat(REGION_L, 0f), p.getFloat(REGION_T, 0f),
            p.getFloat(REGION_R, 0f), p.getFloat(REGION_B, 0f))
    }

    fun clearRegion(context: Context) = prefs(context).edit()
        .remove(REGION_L).remove(REGION_T).remove(REGION_R).remove(REGION_B).apply()
}
