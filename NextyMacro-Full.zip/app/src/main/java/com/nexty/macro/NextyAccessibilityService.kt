package com.nexty.macro

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.graphics.Path
import android.os.Handler
import android.os.Looper
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import android.widget.Toast

class NextyAccessibilityService : AccessibilityService() {
    companion object {
        var instance: NextyAccessibilityService? = null
    }

    private val handler = Handler(Looper.getMainLooper())
    private var playing = false

    override fun onServiceConnected() {
        super.onServiceConnected()
        instance = this
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {}
    override fun onInterrupt() { stop() }

    override fun onDestroy() {
        stop()
        instance = null
        super.onDestroy()
    }

    fun play(macro: Macro) {
        stop()
        if (macro.actions.isEmpty()) return
        playing = true
        playRound(macro, 0)
    }

    fun stop() {
        playing = false
        handler.removeCallbacksAndMessages(null)
    }

    private fun playRound(macro: Macro, round: Int) {
        if (!playing || round >= macro.repeat) {
            playing = false
            return
        }
        playAction(macro.actions, 0) {
            playRound(macro, round + 1)
        }
    }

    private fun playAction(actions: List<MacroAction>, index: Int, done: () -> Unit) {
        if (!playing) return
        if (index >= actions.size) {
            done()
            return
        }

        val a = actions[index]
        when (a.type) {
            ActionType.TAP -> gestureTap(a.x1, a.y1) { next(actions, index, a.delayAfter, done) }
            ActionType.SWIPE -> gestureSwipe(a) { next(actions, index, a.delayAfter, done) }
            ActionType.DELAY -> handler.postDelayed({ playAction(actions, index + 1, done) }, a.duration)
            ActionType.BACK -> {
                performGlobalAction(GLOBAL_ACTION_BACK)
                next(actions, index, a.delayAfter, done)
            }
            ActionType.HOME -> {
                performGlobalAction(GLOBAL_ACTION_HOME)
                next(actions, index, a.delayAfter, done)
            }
            ActionType.RECENTS -> {
                performGlobalAction(GLOBAL_ACTION_RECENTS)
                next(actions, index, a.delayAfter, done)
            }
            ActionType.TEXT -> {
                setFocusedText(a.text)
                next(actions, index, a.delayAfter, done)
            }
        }
    }

    private fun next(actions: List<MacroAction>, index: Int, delay: Long, done: () -> Unit) {
        handler.postDelayed({ playAction(actions, index + 1, done) }, delay.coerceAtLeast(0))
    }

    private fun gestureTap(x: Float, y: Float, done: () -> Unit) {
        val path = Path().apply { moveTo(x, y) }
        val gesture = GestureDescription.Builder()
            .addStroke(GestureDescription.StrokeDescription(path, 0, 50))
            .build()
        dispatchGesture(gesture, object : GestureResultCallback() {
            override fun onCompleted(g: GestureDescription?) { done() }
            override fun onCancelled(g: GestureDescription?) { done() }
        }, null)
    }

    private fun gestureSwipe(a: MacroAction, done: () -> Unit) {
        val path = Path().apply {
            moveTo(a.x1, a.y1)
            lineTo(a.x2, a.y2)
        }
        val gesture = GestureDescription.Builder()
            .addStroke(
                GestureDescription.StrokeDescription(
                    path, 0, a.duration.coerceAtLeast(50)
                )
            )
            .build()
        dispatchGesture(gesture, object : GestureResultCallback() {
            override fun onCompleted(g: GestureDescription?) { done() }
            override fun onCancelled(g: GestureDescription?) { done() }
        }, null)
    }

    private fun setFocusedText(value: String) {
        val root = rootInActiveWindow ?: return
        val node = findEditable(root) ?: return
        val args = android.os.Bundle()
        args.putCharSequence(
            AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE,
            value
        )
        node.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, args)
    }

    private fun findEditable(node: AccessibilityNodeInfo): AccessibilityNodeInfo? {
        if (node.isEditable) return node
        for (i in 0 until node.childCount) {
            val child = node.getChild(i) ?: continue
            val found = findEditable(child)
            if (found != null) return found
        }
        return null
    }
}
