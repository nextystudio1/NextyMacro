NextyMacro v35 - based directly on v30.
Only delay behavior changed: user-configured Delay is kept, but capped at 2000 ms (2 seconds), default 1000 ms. Existing panel, accessibility, click/hold, image condition, and loop behavior are preserved from v30.
