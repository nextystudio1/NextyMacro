package com.nextystudio.nextyimageclick

import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.graphics.BitmapFactory
import android.os.Bundle
import android.provider.Settings as AndroidSettings
import android.view.View
import android.widget.*

class MainActivity : Activity() {
    private val purple = 0xFF6500E8.toInt()
    private val bg = 0xFFF7F5FA.toInt()
    private lateinit var list: LinearLayout
    private lateinit var summary: TextView
    private lateinit var targetPreview: ImageView

    override fun onCreate(savedInstanceState: Bundle?) { super.onCreate(savedInstanceState); buildUi() }
    override fun onResume() { super.onResume(); if (::list.isInitialized) refresh() }

    private fun buildUi() {
        val scroll = ScrollView(this)
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(18, 18, 18, 28); setBackgroundColor(bg) }
        root.addView(TextView(this).apply { text = "NEXTY MACRO"; textSize = 28f; setTextColor(0xFF111111.toInt()); setPadding(4, 4, 4, 8) })
        root.addView(TextView(this).apply { text = "Macro berjalan berurutan. Setelah semua tindakan selesai, loop kembali ke tindakan #1."; textSize = 15f; setTextColor(0xFF444444.toInt()); setPadding(4, 0, 4, 16) })

        root.addView(section("1. GAMBAR TARGET"))
        targetPreview = ImageView(this).apply { scaleType = ImageView.ScaleType.CENTER_INSIDE; setBackgroundColor(0xFFE9E6EF.toInt()) }
        root.addView(targetPreview, LinearLayout.LayoutParams(-1, 150))
        root.addView(button("🖼 PILIH GAMBAR TARGET") { chooseTarget() })
        root.addView(button("▣ PILIH POTONGAN / AREA DETEKSI") { pickRegion() })
        root.addView(label("Match Score: ${Settings.threshold(this)}%   •   Scan: ${Settings.interval(this)} ms"))
        root.addView(button("⚙ PENGATURAN MATCH / SCAN") { showDetectionSettings() })

        root.addView(section("2. DAFTAR TINDAKAN"))
        summary = label("")
        root.addView(summary)
        list = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        root.addView(list)
        root.addView(button("＋ TAMBAH TINDAKAN") { showAddStepDialog() })
        root.addView(button("🔄 ATUR LOOP") { showLoopDialog() })
        root.addView(button("🗑 HAPUS SEMUA TINDAKAN") { clearSteps() })

        root.addView(section("3. JALANKAN"))
        root.addView(button("⚙ AKTIFKAN ACCESSIBILITY") { startActivity(Intent(AndroidSettings.ACTION_ACCESSIBILITY_SETTINGS)) })
        root.addView(button("▶ TAMPILKAN PANEL DI GAME") { NextyAccessibilityService.get()?.showPanel() ?: toast("Aktifkan Accessibility dulu.") })
        root.addView(button("▶ MULAI MACRO") { NextyAccessibilityService.get()?.startMacro() ?: toast("Aktifkan Accessibility dulu.") })
        root.addView(button("■ HENTIKAN MACRO") { NextyAccessibilityService.get()?.stopMacro() ?: toast("Macro tidak aktif.") })

        scroll.addView(root); setContentView(scroll); refresh()
    }

    private fun section(t: String) = TextView(this).apply { text = t; textSize = 21f; setTextColor(0xFF111111.toInt()); setPadding(4, 22, 4, 8) }
    private fun label(t: String) = TextView(this).apply { text = t; textSize = 15f; setTextColor(0xFF333333.toInt()); setPadding(4, 8, 4, 8) }
    private fun button(t: String, action: () -> Unit) = Button(this).apply { text = t; textSize = 16f; setTextColor(0xFFFFFFFF.toInt()); setBackgroundColor(purple); setOnClickListener { action() } }

    private fun chooseTarget() {
        startActivityForResult(Intent(Intent.ACTION_OPEN_DOCUMENT).apply { type = "image/*"; addCategory(Intent.CATEGORY_OPENABLE) }, 10)
    }

    private fun pickRegion() {
        NextyAccessibilityService.get()?.startRegionPicker() ?: toast("Aktifkan Accessibility dulu.")
    }

    private fun showDetectionSettings() {
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(30, 10, 30, 0) }
        val score = SeekBar(this).apply { max = 50; progress = Settings.threshold(this@MainActivity) - 50 }
        val scoreText = label("Match Score: ${Settings.threshold(this)}%")
        score.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar?, p: Int, fromUser: Boolean) { Settings.saveThreshold(this@MainActivity, p + 50); scoreText.text = "Match Score: ${p + 50}%" }
            override fun onStartTrackingTouch(s: SeekBar?) {}
            override fun onStopTrackingTouch(s: SeekBar?) {}
        })
        val scan = SeekBar(this).apply { max = 29; progress = ((Settings.interval(this@MainActivity) - 100L) / 100L).toInt().coerceIn(0, 29) }
        val scanText = label("Scan Rate: ${Settings.interval(this)} ms")
        scan.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar?, p: Int, fromUser: Boolean) { Settings.saveInterval(this@MainActivity, 100L + p * 100L); scanText.text = "Scan Rate: ${100 + p * 100} ms" }
            override fun onStartTrackingTouch(s: SeekBar?) {}
            override fun onStopTrackingTouch(s: SeekBar?) {}
        })
        box.addView(scoreText); box.addView(score); box.addView(scanText); box.addView(scan)
        AlertDialog.Builder(this).setTitle("Pengaturan Deteksi").setView(box).setPositiveButton("Simpan", null).show()
    }

    private fun showAddStepDialog() {
        val choices = arrayOf("🖼 Kondisi: Gambar Muncul", "🖱 Tindakan: Klik hasil gambar", "👆 Tindakan: Klik koordinat", "⏱ Tindakan: Delay")
        AlertDialog.Builder(this).setTitle("Tambah Tindakan").setItems(choices) { _, which ->
            when (which) {
                0 -> addStep(MacroStep(StepType.CONDITION_IMAGE, "Gambar Muncul → tunggu sampai ditemukan"))
                1 -> addStep(MacroStep(StepType.CLICK_DETECTED, "Klik → posisi gambar yang ditemukan"))
                2 -> pickCoordinateStep()
                3 -> showDelayDialog()
            }
        }.show()
    }

    private fun pickCoordinateStep() {
        NextyAccessibilityService.get()?.startCoordinatePicker { p ->
            addStep(MacroStep(StepType.CLICK_COORD, "Klik koordinat (${p.x.toInt()}, ${p.y.toInt()})", x = p.x, y = p.y))
        } ?: toast("Aktifkan Accessibility dulu.")
    }

    private fun showDelayDialog() {
        val input = EditText(this).apply { inputType = android.text.InputType.TYPE_CLASS_NUMBER; hint = "milidetik"; setText("500") }
        AlertDialog.Builder(this).setTitle("Delay").setView(input).setPositiveButton("Tambah") { _, _ ->
            val ms = input.text.toString().toLongOrNull()?.coerceAtLeast(0L) ?: 500L
            addStep(MacroStep(StepType.DELAY, "Delay ${ms} ms", delayMs = ms))
        }.setNegativeButton("Batal", null).show()
    }

    private fun addStep(step: MacroStep) {
        val steps = MacroStore.getSteps(this); steps.add(step); MacroStore.saveSteps(this, steps); refresh()
    }

    private fun removeStep(index: Int) {
        val steps = MacroStore.getSteps(this)
        if (index in steps.indices) { steps.removeAt(index); MacroStore.saveSteps(this, steps); refresh() }
    }

    private fun clearSteps() {
        AlertDialog.Builder(this).setTitle("Hapus semua?").setMessage("Semua tindakan macro akan dihapus.").setNegativeButton("Batal", null).setPositiveButton("Hapus") { _, _ -> MacroStore.saveSteps(this, emptyList()); refresh() }.show()
    }

    private fun showLoopDialog() {
        val modes = arrayOf("Sekali", "Ulangi jumlah tertentu", "Tanpa batas")
        val selected = MacroStore.loopMode(this)
        AlertDialog.Builder(this).setTitle("Loop Macro").setSingleChoiceItems(modes, selected) { dialog, which ->
            if (which == 1) {
                val input = EditText(this).apply { inputType = android.text.InputType.TYPE_CLASS_NUMBER; hint = "jumlah putaran"; setText(MacroStore.loopCount(this@MainActivity).toString()) }
                AlertDialog.Builder(this).setTitle("Jumlah putaran").setView(input).setPositiveButton("Simpan") { _, _ -> MacroStore.saveLoop(this, 1, input.text.toString().toIntOrNull() ?: 1); refresh() }.show()
            } else { MacroStore.saveLoop(this, which, MacroStore.loopCount(this)); refresh() }
            dialog.dismiss()
        }.show()
    }

    private fun refresh() {
        if (!::list.isInitialized) return
        targetPreview.setImageBitmap(if (Settings.targetExists(this)) BitmapFactory.decodeFile(Settings.targetPath(this)) else null)
        list.removeAllViews()
        val steps = MacroStore.getSteps(this)
        summary.text = "${steps.size} tindakan • ${loopDescription()}\nUrutan dijalankan 1 → ${steps.size} → kembali ke 1"
        steps.forEachIndexed { index, step ->
            val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; setPadding(0, 4, 0, 4) }
            val text = TextView(this).apply { text = "${index + 1}. ${step.title}"; textSize = 16f; setTextColor(0xFF222222.toInt()); setPadding(14, 12, 8, 12) }
            row.addView(text, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
            row.addView(Button(this).apply { setText("✕"); setOnClickListener { removeStep(index) } })
            list.addView(row)
        }
    }

    private fun loopDescription(): String = when (MacroStore.loopMode(this)) { 0 -> "1 putaran"; 1 -> "${MacroStore.loopCount(this)} putaran"; else -> "tanpa batas" }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == 10 && resultCode == RESULT_OK) data?.data?.let { uri -> contentResolver.openInputStream(uri)?.use { Settings.saveTarget(this, it.readBytes()) }; refresh(); toast("Gambar target tersimpan.") }
    }

    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_SHORT).show()
}
