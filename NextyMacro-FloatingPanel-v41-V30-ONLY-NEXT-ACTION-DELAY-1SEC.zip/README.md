# Nexty Macro v41

Exact base: user-uploaded v30.

Only change: after an action completes, wait 1000 ms (1 second) before continuing to the next action. Accessibility, click, hold, conditions, loops, panel, and explicit DELAY action are unchanged.
