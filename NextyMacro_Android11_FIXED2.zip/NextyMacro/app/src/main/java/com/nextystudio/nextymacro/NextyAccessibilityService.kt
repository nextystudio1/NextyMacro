package com.nextystudio.nextymacro

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.graphics.*
import android.os.*
import android.view.*
import android.widget.*
import java.io.File
import kotlin.math.abs
import kotlin.math.min

class NextyAccessibilityService : AccessibilityService() {
    private var running=false
    private var actions=emptyList<MacroAction>()
    private var conditions=emptyList<Condition>()
    private var index=0
    private var picker=false
    private var pickerView: View?=null
    private var callback:((Int,Int)->Unit)?=null
    private var overlay: WindowManager?=null
    private val handler=Handler(Looper.getMainLooper())

    override fun onServiceConnected() { instance=this }
    override fun onAccessibilityEvent(event: android.view.accessibility.AccessibilityEvent?) {}
    override fun onInterrupt() { running=false }

    fun startInternal(a:List<MacroAction>,c:List<Condition>){
        actions=a; conditions=c; index=0; running=true
        runNext()
    }
    private fun runNext(){
        if(!running || actions.isEmpty()) return
        val a=actions[index]
        val condition=conditions.firstOrNull{it.id==a.conditionId}
        if(condition==null){
            tap(a.x,a.y)
            next(a)
        } else {
            waitForCondition(condition,a)
        }
    }
    private fun next(a:MacroAction){
        handler.postDelayed({
            if(!running)return@postDelayed
            index=(index+1)%actions.size
            runNext()
        }, a.delayMs.coerceAtLeast(0))
    }

    private fun waitForCondition(c:Condition,a:MacroAction){
        if(!running)return
        takeScreenshot(android.view.Display.DEFAULT_DISPLAY, mainExecutor, object:TakeScreenshotCallback{
            override fun onSuccess(result:ScreenshotResult){
                val hardware = result.hardwareBuffer
                val wrapped = Bitmap.wrapHardwareBuffer(hardware, result.colorSpace)
                hardware.close()
                if (wrapped == null) {
                    handler.postDelayed({ waitForCondition(c,a) }, 500)
                    return
                }
                val bmp = wrapped.copy(Bitmap.Config.ARGB_8888, false)
                wrapped.recycle()
                val template = BitmapFactory.decodeFile(c.imagePath)
                val ok = ImageMatcher.matches(bmp, template, c.threshold)
                template?.recycle()
                bmp.recycle()
                if(ok){ tap(a.x,a.y); next(a) }
                else handler.postDelayed({waitForCondition(c,a)},250)
            }
            override fun onFailure(errorCode:Int){ handler.postDelayed({waitForCondition(c,a)},500) }
        })
    }

    private fun tap(x:Int,y:Int){
        val p=Path().apply{moveTo(x.toFloat(),y.toFloat())}
        val g=GestureDescription.Builder().addStroke(GestureDescription.StrokeDescription(p,0,40)).build()
        dispatchGesture(g,null,null)
    }

    private fun beginPick(){
        if(picker)return
        picker=true
        val wm=getSystemService(WINDOW_SERVICE) as WindowManager
        overlay=wm
        val v=View(this)
        v.setBackgroundColor(Color.argb(40,0,0,0))
        v.setOnTouchListener { _,e ->
            if(e.action==MotionEvent.ACTION_UP){
                callback?.invoke(e.rawX.toInt(),e.rawY.toInt())
                endPick()
            }
            true
        }
        val lp=WindowManager.LayoutParams(-1,-1,WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT)
        wm.addView(v,lp); pickerView=v
    }
    private fun endPick(){
        picker=false
        pickerView?.let{overlay?.removeView(it)}
        pickerView=null
    }

    companion object {
        private var instance:NextyAccessibilityService?=null
        fun startMacro(a:List<MacroAction>,c:List<Condition>){instance?.startInternal(a,c)}
        fun stopMacro(){instance?.running=false}
        fun beginCoordinatePick(){instance?.beginPick()}
        fun setCoordinateCallback(cb:(Int,Int)->Unit){instance?.callback=cb}
    }
}

object ImageMatcher {
    fun matches(screen:Bitmap, templ:Bitmap?, threshold:Int):Boolean {
        if(templ==null || screen.width<templ.width || screen.height<templ.height)return false
        val maxW=220
        val t=if(templ.width>maxW || templ.height>maxW) scale(templ,maxW) else templ
        val step=6
        val sw=screen.width-t.width
        val sh=screen.height-t.height
        val sample=8
        var y=0
        while(y<=sh){
            var x=0
            while(x<=sw){
                if(score(screen,t,x,y,sample)>=threshold)return true
                x+=step
            }
            y+=step
        }
        return false
    }
    private fun score(s:Bitmap,t:Bitmap,x:Int,y:Int,n:Int):Int{
        var total=0L; var count=0
        for(j in 0 until n){
            for(i in 0 until n){
                val tx=i*t.width/n; val ty=j*t.height/n
                val sc=s.getPixel(x+tx,y+ty); val tc=t.getPixel(tx,ty)
                val d=abs(Color.red(sc)-Color.red(tc))+abs(Color.green(sc)-Color.green(tc))+abs(Color.blue(sc)-Color.blue(tc))
                total += d; count++
            }
        }
        val avg=total.toDouble()/count
        return (100.0 - min(100.0,avg/7.65)).toInt()
    }
    private fun scale(b:Bitmap,max:Int):Bitmap{
        val r=min(max.toFloat()/b.width,max.toFloat()/b.height)
        return Bitmap.createScaledBitmap(b,(b.width*r).toInt().coerceAtLeast(1),(b.height*r).toInt().coerceAtLeast(1),true)
    }
}
