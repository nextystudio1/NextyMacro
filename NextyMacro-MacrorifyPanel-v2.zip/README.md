# NextyMacro Macrorify Panel v2

Konsep utama:
- Satu panel berisi daftar tindakan.
- Setiap kartu adalah TINDAKAN.
- Tindakan klik memakai koordinat tetap (X,Y).
- Setiap tindakan bisa memiliki KONDISI gambar.
- Jika kondisi gambar aktif, macro menunggu gambar target ditemukan di area pencarian.
- Setelah kondisi terpenuhi, tindakan dijalankan pada koordinat yang disimpan.
- Setelah tindakan selesai, lanjut ke kartu berikutnya.
- Setelah kartu terakhir selesai, loop kembali ke kartu #1 sesuai pengaturan loop.

Alur contoh:
1. Klik (650,400) + kondisi gambar A
2. Delay 500 ms
3. Klik (900,500) + kondisi gambar B
4. Klik (300,700) tanpa kondisi
-> selesai -> kembali ke #1.

Kondisi gambar:
- template gambar per tindakan
- match threshold
- scan interval
- area pencarian

Build:
gradle :app:assembleDebug
