package com.nextystudio.nextyimageclick

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

enum class StepType { CONDITION_IMAGE, CLICK_DETECTED, DELAY, CLICK_COORD }

data class MacroStep(
    val type: StepType,
    val title: String,
    val delayMs: Long = 0L,
    val x: Float = 0f,
    val y: Float = 0f
)

object MacroStore {
    private const val PREF = "nexty_macro"
    private const val STEPS = "steps"
    private const val LOOP_MODE = "loop_mode" // 0 once, 1 count, 2 forever
    private const val LOOP_COUNT = "loop_count"

    private fun prefs(c: Context) = c.getSharedPreferences(PREF, Context.MODE_PRIVATE)

    fun getSteps(c: Context): MutableList<MacroStep> {
        val raw = prefs(c).getString(STEPS, null) ?: return mutableListOf()
        return try {
            val a = JSONArray(raw)
            MutableList(a.length()) { i ->
                val o = a.getJSONObject(i)
                MacroStep(
                    StepType.valueOf(o.optString("type", StepType.DELAY.name)),
                    o.optString("title", "Tindakan"),
                    o.optLong("delay", 0L),
                    o.optDouble("x", 0.0).toFloat(),
                    o.optDouble("y", 0.0).toFloat()
                )
            }
        } catch (_: Throwable) { mutableListOf() }
    }

    fun saveSteps(c: Context, steps: List<MacroStep>) {
        val a = JSONArray()
        steps.forEach { s ->
            a.put(JSONObject().apply {
                put("type", s.type.name)
                put("title", s.title)
                put("delay", s.delayMs)
                put("x", s.x)
                put("y", s.y)
            })
        }
        prefs(c).edit().putString(STEPS, a.toString()).apply()
    }

    fun loopMode(c: Context) = prefs(c).getInt(LOOP_MODE, 2)
    fun loopCount(c: Context) = prefs(c).getInt(LOOP_COUNT, 10).coerceAtLeast(1)
    fun saveLoop(c: Context, mode: Int, count: Int) = prefs(c).edit()
        .putInt(LOOP_MODE, mode.coerceIn(0, 2))
        .putInt(LOOP_COUNT, count.coerceAtLeast(1))
        .apply()
}
