package com.nextystudio.nextyimageclick

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.graphics.Bitmap
import android.graphics.Path
import android.graphics.PointF
import android.hardware.HardwareBuffer
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.view.*
import android.widget.*
import android.content.Intent
import java.util.concurrent.Executors
import kotlin.math.max

class NextyAccessibilityService : AccessibilityService() {
    companion object {
        const val ACTION_SHOW = "nexty.show"
        const val ACTION_START = "nexty.start"
        const val ACTION_STOP = "nexty.stop"
        private var instance: NextyAccessibilityService? = null
        fun get(): NextyAccessibilityService? = instance
    }

    private val main = Handler(Looper.getMainLooper())
    private val executor = Executors.newSingleThreadExecutor()
    private var overlay: View? = null
    private var panel: LinearLayout? = null
    private var detectorOn = false
    private var pickerOn = false
    private var lastClick = 0L
    private var busy = false

    override fun onServiceConnected() {
        super.onServiceConnected()
        instance = this
    }

    override fun onDestroy() {
        instance = null
        executor.shutdownNow()
        removeOverlay()
        super.onDestroy()
    }

    override fun onAccessibilityEvent(event: android.view.accessibility.AccessibilityEvent?) {}
    override fun onInterrupt() {}

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_SHOW) showPanel()
        if (intent?.action == ACTION_START) startDetector()
        if (intent?.action == ACTION_STOP) stopDetector()
        return START_STICKY
    }

    fun showPanel() {
        main.post {
            if (panel != null) return@post
            val wm = getSystemService(WINDOW_SERVICE) as WindowManager
            val p = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                setPadding(12, 12, 12, 12)
                setBackgroundColor(0xEE1B1B1B.toInt())
            }
            val title = TextView(this).apply {
                text = "NEXTY"
                textSize = 14f
                setTextColor(0xFFFFFFFF.toInt())
                setPadding(8, 4, 8, 8)
            }
            p.addView(title)
            val direction = Button(this).apply {
                text = "🎯 ARAH KLIK"
                setOnClickListener { startPicker() }
            }
            val image = Switch(this).apply {
                text = "🖼 GAMBAR"
                setTextColor(0xFFFFFFFF.toInt())
                isChecked = Settings.targetExists(this@NextyAccessibilityService)
                setOnCheckedChangeListener { _, checked ->
                    if (checked) startDetector() else stopDetector()
                }
            }
            val start = Button(this).apply {
                text = "▶ START"
                setOnClickListener { startDetector() }
            }
            val stop = Button(this).apply {
                text = "■ STOP"
                setOnClickListener { stopDetector() }
            }
            val close = Button(this).apply {
                text = "× TUTUP"
                setOnClickListener { removeOverlay() }
            }
            p.addView(direction)
            p.addView(image)
            p.addView(start)
            p.addView(stop)
            p.addView(close)

            val lp = WindowManager.LayoutParams(
                210, WindowManager.LayoutParams.WRAP_CONTENT,
                WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
                android.graphics.PixelFormat.TRANSLUCENT
            ).apply {
                gravity = Gravity.TOP or Gravity.END
                x = 12
                y = 80
            }
            title.setOnTouchListener(object: View.OnTouchListener {
                var downX=0f; var downY=0f; var startX=0; var startY=0
                override fun onTouch(v: View, e: MotionEvent): Boolean {
                    when(e.action) {
                        MotionEvent.ACTION_DOWN -> { downX=e.rawX; downY=e.rawY; startX=lp.x; startY=lp.y; return true }
                        MotionEvent.ACTION_MOVE -> { lp.x=startX+(e.rawX-downX).toInt(); lp.y=startY+(e.rawY-downY).toInt(); wm.updateViewLayout(p,lp); return true }
                        MotionEvent.ACTION_UP -> return true
                    }
                    return false
                }
            })
            wm.addView(p, lp)
            panel = p
        }
    }

    private fun startPicker() {
        if (pickerOn) return
        pickerOn = true
        val wm = getSystemService(WINDOW_SERVICE) as WindowManager
        val pick = FrameLayout(this).apply {
            setBackgroundColor(0x22000000)
            val label = TextView(this@NextyAccessibilityService).apply {
                text = "TAP POSISI KLIK
(ketuk sekali)"
                textSize = 24f
                gravity = Gravity.CENTER
                setTextColor(0xFFFFFFFF.toInt())
                setBackgroundColor(0xAA000000.toInt())
                setPadding(30, 20, 30, 20)
            }
            addView(label, FrameLayout.LayoutParams(-2,-2,Gravity.CENTER))
            setOnTouchListener { _, e ->
                if (e.action == MotionEvent.ACTION_UP) {
                    Settings.savePoint(this@NextyAccessibilityService, PointF(e.rawX, e.rawY))
                    Toast.makeText(this@NextyAccessibilityService, "Titik klik tersimpan: ${e.rawX.toInt()}, ${e.rawY.toInt()}", Toast.LENGTH_SHORT).show()
                    wm.removeView(this)
                    pickerOn=false
                    true
                } else true
            }
        }
        val lp=WindowManager.LayoutParams(
            -1,-1,WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            android.graphics.PixelFormat.TRANSLUCENT
        )
        wm.addView(pick,lp)
    }

    private fun startDetector() {
        if (detectorOn || !Settings.targetExists(this)) {
            if (!Settings.targetExists(this)) Toast.makeText(this,"Pilih gambar target dulu.",Toast.LENGTH_SHORT).show()
            return
        }
        if (Settings.getPoint(this)==null) {
            Toast.makeText(this,"Atur ARAH KLIK dulu.",Toast.LENGTH_SHORT).show()
            return
        }
        detectorOn=true
        scheduleCapture()
    }

    private fun stopDetector() {
        detectorOn=false
        busy=false
    }

    private fun scheduleCapture() {
        if (!detectorOn) return
        takeShot()
        main.postDelayed({ scheduleCapture() }, Settings.interval(this))
    }

    private fun takeShot() {
        if (busy || Build.VERSION.SDK_INT < 30) return
        busy=true
        takeScreenshot(
            0,
            executor,
            object : TakeScreenshotCallback {
                override fun onSuccess(result: ScreenshotResult) {
                    try {
                        val hw = result.hardwareBuffer
                        val bmp0 = Bitmap.wrapHardwareBuffer(hw, result.colorSpace)
                        hw.close()
                        if (bmp0 != null) {
                            val bmp = bmp0.copy(Bitmap.Config.ARGB_8888, false)
                            bmp0.recycle()
                            executor.execute {
                                val target = BitmapFactoryCompat.load(this@NextyAccessibilityService)
                                val match = if (target != null) ImageMatcher.find(bmp, target, Settings.threshold(this@NextyAccessibilityService)) else MatchResult(false)
                                bmp.recycle()
                                if (match.found) {
                                    val now=System.currentTimeMillis()
                                    if (now-lastClick>700) {
                                        lastClick=now
                                        main.post { performTap(Settings.getPoint(this@NextyAccessibilityService)) }
                                    }
                                }
                                busy=false
                            }
                        } else busy=false
                    } catch (_: Throwable) { busy=false }
                }
                override fun onFailure(errorCode: Int) { busy=false }
            }
        )
    }

    private fun performTap(p: PointF?) {
        if (p == null) return
        val path=Path().apply { moveTo(p.x,p.y) }
        val gesture=GestureDescription.Builder()
            .addStroke(GestureDescription.StrokeDescription(path,0,80))
            .build()
        dispatchGesture(gesture,null,null)
    }

    private fun removeOverlay() {
        main.post {
            val wm=getSystemService(WINDOW_SERVICE) as WindowManager
            panel?.let { try { wm.removeView(it) } catch (_:Throwable){} }
            panel=null
            stopDetector()
        }
    }
}

private object BitmapFactoryCompat {
    fun load(c: android.content.Context): Bitmap? =
        android.graphics.BitmapFactory.decodeFile(Settings.targetPath(c))
}
