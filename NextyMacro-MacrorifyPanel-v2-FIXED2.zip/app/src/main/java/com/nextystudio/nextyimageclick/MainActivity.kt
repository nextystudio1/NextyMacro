package com.nextystudio.nextyimageclick

import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.graphics.BitmapFactory
import android.graphics.Color
import android.os.Bundle
import android.provider.Settings as AndroidSettings
import android.text.InputType
import android.view.Gravity
import android.view.View
import android.widget.*

class MainActivity : Activity() {
    private val bg = Color.rgb(244,243,247)
    private val card = Color.WHITE
    private val purple = Color.rgb(96, 54, 190)
    private val orange = Color.rgb(242, 158, 45)
    private val blue = Color.rgb(66, 112, 205)
    private lateinit var stepsBox: LinearLayout
    private var pendingTargetIndex = -1
    private var pendingAction = false

    override fun onCreate(savedInstanceState: Bundle?) { super.onCreate(savedInstanceState); buildPanel() }
    override fun onResume() { super.onResume(); if (::stepsBox.isInitialized) refresh() }

    private fun buildPanel() {
        val scroll = ScrollView(this)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(12,12,12,28)
            setBackgroundColor(bg)
        }
        root.addView(label("NEXTY • MACRO PANEL", 25f, Color.rgb(25,25,30)))
        root.addView(label("Tindakan = apa yang dilakukan. Kondisi = syarat agar tindakan dijalankan.", 14f, Color.DKGRAY))
        root.addView(infoCard())
        root.addView(label("DAFTAR TINDAKAN", 19f, Color.rgb(25,25,30)), margin(0,12,0,5))
        stepsBox = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        root.addView(stepsBox)
        val add = LinearLayout(this).apply { gravity=Gravity.CENTER }
        add.addView(button("＋ TINDAKAN", blue) { addActionMenu() }, weight())
        root.addView(add, margin(0,8,0,8))
        root.addView(loopCard())
        root.addView(controlCard())
        scroll.addView(root); setContentView(scroll); refresh()
    }

    private fun infoCard() = LinearLayout(this).apply {
        orientation=LinearLayout.VERTICAL; setPadding(14,12,14,12); setBackgroundColor(card)
        addView(label("CARA KERJA",17f,Color.rgb(30,30,30)))
        addView(label("Setiap kartu adalah satu tindakan. Contoh: klik (650,400). Jika kondisi gambar di kartu itu aktif, Nexty menunggu gambar ditemukan di area pencarian. Setelah terpenuhi, barulah koordinat (650,400) diklik. Setelah tindakan selesai, lanjut ke kartu berikutnya.",14f,Color.DKGRAY))
    }.also { it.layoutParams=margin(0,8,0,8) }

    private fun stepCard(index:Int, s:MacroStep):View {
        val box=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(14,12,14,12);setBackgroundColor(card)}
        val head=LinearLayout(this).apply{gravity=Gravity.CENTER_VERTICAL}
        head.addView(label("${index+1}",20f,blue))
        head.addView(Space(this), LinearLayout.LayoutParams(0,1,1f))
        head.addView(textButton("↑"){move(index,-1)})
        head.addView(textButton("↓"){move(index,1)})
        head.addView(textButton("✕"){remove(index)})
        box.addView(head)
        box.addView(label(if(s.type==StepType.DELAY) "TUNGGU / DELAY" else "TINDAKAN • KLIK",16f,blue))
        box.addView(label(actionDetail(s),14f,Color.DKGRAY))
        val actionEdit=button("EDIT TINDAKAN",blue){editAction(index)}
        box.addView(actionEdit,margin(0,5,0,2))
        val cond=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(10,8,10,8);setBackgroundColor(Color.rgb(255,247,231))}
        cond.addView(label("KONDISI",15f,orange))
        if(s.conditionImage){
            val has=Settings.stepTargetExists(this,s.id)
            cond.addView(label(if(has) "✓ Gambar terpenuhi: template tersimpan" else "⚠ Kondisi gambar aktif, tapi gambar belum dipilih",13f,Color.DKGRAY))
            cond.addView(label("Match ${s.conditionThreshold}% • scan ${s.conditionInterval} ms • area pencarian dari ATUR AREA",13f,Color.DKGRAY))
            val cr=LinearLayout(this).apply{gravity=Gravity.CENTER}
            cr.addView(button("PILIH Gambar",orange){chooseStepTarget(index)},weight())
            cr.addView(button("ATUR AREA",orange){NextyAccessibilityService.get()?.startRegionPicker()?:toast("Aktifkan Accessibility dulu.")},weight())
            cr.addView(button("EDIT",orange){editCondition(index)},weight())
            cond.addView(cr)
        }else{
            cond.addView(label("Tidak ada kondisi • tindakan selalu dijalankan",13f,Color.DKGRAY))
            cond.addView(button("＋ TAMBAH KONDISI GAMBAR",orange){enableCondition(index)},margin(0,4,0,0))
        }
        box.addView(cond,margin(0,6,0,0))
        return box.also{it.layoutParams=margin(0,0,0,8)}
    }

    private fun actionDetail(s:MacroStep)=when(s.type){
        StepType.DELAY -> "Delay ${s.delayMs} ms"
        else -> "Klik koordinat  X=${s.x.toInt()}   Y=${s.y.toInt()}"
    }

    private fun addActionMenu(){
        AlertDialog.Builder(this).setTitle("Tambah Tindakan").setItems(arrayOf("Klik koordinat","Delay")){_,which->
            if(which==0) pickCoordinate()
            else showDelay(-1)
        }.show()
    }
    private fun pickCoordinate(){
        NextyAccessibilityService.get()?.startCoordinatePicker{p->
            val x=MacroStore.getSteps(this)
            x.add(MacroStep(StepType.CLICK_COORD,"Klik koordinat",x=p.x,y=p.y))
            MacroStore.saveSteps(this,x);refresh()
        }?:toast("Aktifkan Accessibility dulu.")
    }
    private fun editAction(i:Int){
        val steps=MacroStore.getSteps(this); if(i !in steps.indices)return
        val s=steps[i]
        if(s.type==StepType.DELAY){showDelay(i);return}
        NextyAccessibilityService.get()?.startCoordinatePicker{p->
            val x=MacroStore.getSteps(this)
            if(i in x.indices){x[i]=x[i].copy(title="Klik koordinat",x=p.x,y=p.y);MacroStore.saveSteps(this,x);refresh()}
        }?:toast("Aktifkan Accessibility dulu.")
    }
    private fun showDelay(index:Int){
        val input=EditText(this).apply{inputType=InputType.TYPE_CLASS_NUMBER;setText(if(index>=0)MacroStore.getSteps(this@MainActivity)[index].delayMs.toString() else "500")}
        AlertDialog.Builder(this).setTitle("Delay (ms)").setView(input).setPositiveButton("Simpan"){_,_->
            val ms=input.text.toString().toLongOrNull()?.coerceAtLeast(0L)?:500L
            val x=MacroStore.getSteps(this)
            if(index<0)x.add(MacroStep(StepType.DELAY,"Delay $ms ms",delayMs=ms))
            else if(index<x.size)x[index]=x[index].copy(title="Delay $ms ms",delayMs=ms)
            MacroStore.saveSteps(this,x);refresh()
        }.setNegativeButton("Batal",null).show()
    }
    private fun enableCondition(i:Int){
        val x=MacroStore.getSteps(this); if(i !in x.indices)return
        x[i]=x[i].copy(conditionImage=true,conditionThreshold=85,conditionInterval=500)
        MacroStore.saveSteps(this,x); refresh()
        chooseStepTarget(i)
    }
    private fun editCondition(i:Int){
        val s=MacroStore.getSteps(this)[i]
        val box=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(20,8,20,0)}
        val match=SeekBar(this).apply{max=50;progress=s.conditionThreshold-50}
        val mt=label("Match ${s.conditionThreshold}%",14f,Color.DKGRAY)
        match.setOnSeekBarChangeListener(object:SeekBar.OnSeekBarChangeListener{
            override fun onProgressChanged(sb:SeekBar?,p:Int,from:Boolean){mt.text="Match ${p+50}%"}
            override fun onStartTrackingTouch(sb:SeekBar?){}
            override fun onStopTrackingTouch(sb:SeekBar?){}
        })
        val scan=EditText(this).apply{inputType=InputType.TYPE_CLASS_NUMBER;setText(s.conditionInterval.toString());hint="ms"}
        box.addView(mt);box.addView(match);box.addView(label("Scan interval (ms)",13f,Color.DKGRAY));box.addView(scan)
        AlertDialog.Builder(this).setTitle("Kondisi • Gambar ditemukan").setView(box).setPositiveButton("Simpan"){_,_->
            val x=MacroStore.getSteps(this)
            if(i<x.size)x[i]=x[i].copy(conditionImage=true,conditionThreshold=match.progress+50,conditionInterval=scan.text.toString().toLongOrNull()?.coerceIn(100L,3000L)?:500L)
            MacroStore.saveSteps(this,x);refresh()
        }.setNegativeButton("Batal",null).show()
    }
    private fun chooseStepTarget(index:Int){
        pendingTargetIndex=index
        startActivityForResult(Intent(Intent.ACTION_OPEN_DOCUMENT).apply{type="image/*";addCategory(Intent.CATEGORY_OPENABLE)},1001)
    }

    private fun refresh(){
        if(!::stepsBox.isInitialized)return
        val x=MacroStore.getSteps(this)
        stepsBox.removeAllViews()
        if(x.isEmpty())stepsBox.addView(label("Belum ada tindakan. Tekan ＋ TINDAKAN.",14f,Color.DKGRAY))
        x.forEachIndexed{ i,s->stepsBox.addView(stepCard(i,s))}
    }
    private fun move(i:Int,d:Int){val x=MacroStore.getSteps(this);val j=i+d;if(i in x.indices&&j in x.indices){val t=x.removeAt(i);x.add(j,t);MacroStore.saveSteps(this,x);refresh()}}
    private fun remove(i:Int){val x=MacroStore.getSteps(this);if(i in x.indices){x.removeAt(i);MacroStore.saveSteps(this,x);refresh()}}
    private fun loopCard()=LinearLayout(this).apply{
        orientation=LinearLayout.VERTICAL;setPadding(14,12,14,12);setBackgroundColor(card)
        addView(label("LOOP",17f,Color.rgb(30,30,30)))
        addView(label("${loopDescription()} • setelah tindakan terakhir selesai → kembali ke tindakan #1",14f,Color.DKGRAY))
        addView(button("ATUR LOOP",purple){showLoopDialog()})
    }.also{it.layoutParams=margin(0,0,0,8)}
    private fun controlCard()=LinearLayout(this).apply{
        orientation=LinearLayout.VERTICAL;setPadding(14,12,14,12);setBackgroundColor(card)
        addView(label("KONTROL",17f,Color.rgb(30,30,30)))
        addView(button("⚙ AKTIFKAN ACCESSIBILITY"){startActivity(Intent(AndroidSettings.ACTION_ACCESSIBILITY_SETTINGS))})
        addView(button("☰ TAMPILKAN PANEL DI GAME"){NextyAccessibilityService.get()?.showPanel()?:toast("Aktifkan Accessibility dulu.")})
        val r=LinearLayout(this@MainActivity).apply{gravity=Gravity.CENTER}
        r.addView(button("▶ MULAI",purple){NextyAccessibilityService.get()?.startMacro()?:toast("Aktifkan Accessibility dulu.")},weight())
        r.addView(button("■ STOP",Color.DKGRAY){NextyAccessibilityService.get()?.stopMacro()},weight())
        addView(r)
    }.also{it.layoutParams=margin(0,0,0,8)}
    private fun showLoopDialog(){
        val modes=arrayOf("Sekali","Ulangi N kali","Tanpa batas")
        AlertDialog.Builder(this).setTitle("Loop macro").setSingleChoiceItems(modes,MacroStore.loopMode(this)){d,w->
            if(w==1){
                val inpt=EditText(this).apply{inputType=InputType.TYPE_CLASS_NUMBER;setText(MacroStore.loopCount(this@MainActivity).toString())}
                AlertDialog.Builder(this).setTitle("Jumlah putaran").setView(inpt).setPositiveButton("Simpan"){_,_->MacroStore.saveLoop(this,1,inpt.text.toString().toIntOrNull()?:1);refresh()}.show()
            }else{MacroStore.saveLoop(this,w,MacroStore.loopCount(this));refresh()}
            d.dismiss()
        }.show()
    }
    private fun loopDescription()=when(MacroStore.loopMode(this)){0->"1 putaran";1->"${MacroStore.loopCount(this)} putaran";else->"Tanpa batas"}
    override fun onActivityResult(requestCode:Int,resultCode:Int,data:Intent?){
        super.onActivityResult(requestCode,resultCode,data)
        if(requestCode==1001&&resultCode==RESULT_OK&&pendingTargetIndex>=0){
            data?.data?.let{u->contentResolver.openInputStream(u)?.use{Settings.saveStepTarget(this,MacroStore.getSteps(this)[pendingTargetIndex].id,it.readBytes())};refresh();toast("Gambar kondisi tersimpan")}
        }
    }
    private fun label(s:String,size:Float,color:Int)=TextView(this).apply{text=s;textSize=size;setTextColor(color);setPadding(2,3,2,3)}
    private fun button(s:String,color:Int=purple,a:()->Unit={})=Button(this).apply{text=s;textSize=12f;setTextColor(Color.WHITE);setBackgroundColor(color);setOnClickListener{a()}}
    private fun textButton(s:String,a:()->Unit)=TextView(this).apply{text=s;textSize=18f;setPadding(10,2,10,2);setTextColor(Color.DKGRAY);setOnClickListener{a()}}
    private fun weight()=LinearLayout.LayoutParams(0,-2,1f).apply{setMargins(4,4,4,4)}
    private fun margin(l:Int,t:Int,r:Int,b:Int)=LinearLayout.LayoutParams(-1,-2).apply{setMargins(l,t,r,b)}
    private fun toast(s:String)=Toast.makeText(this,s,Toast.LENGTH_SHORT).show()
}
