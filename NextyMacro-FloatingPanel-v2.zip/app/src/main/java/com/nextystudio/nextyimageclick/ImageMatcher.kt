package com.nextystudio.nextyimageclick

import android.graphics.Bitmap
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min

data class MatchResult(val found: Boolean, val x: Float = 0f, val y: Float = 0f, val score: Int = 0)

object ImageMatcher {
    /**
     * Lightweight template matching. It compares a grayscale target against
     * sampled screen patches. It is intentionally dependency-free so the APK
     * stays small and buildable.
     */
    fun find(screen: Bitmap, target: Bitmap, threshold: Int): MatchResult {
        if (target.width < 4 || target.height < 4) return MatchResult(false)
        val maxTargetW = 80
        val maxTargetH = 80
        val t = scale(target, min(1f, min(maxTargetW.toFloat() / target.width, maxTargetH.toFloat() / target.height)))
        if (t.width >= screen.width || t.height >= screen.height) return MatchResult(false)

        val step = 8
        val tw = t.width
        val th = t.height
        val tp = IntArray(tw * th)
        t.getPixels(tp, 0, tw, 0, 0, tw, th)
        val tg = IntArray(tp.size)
        var tSum = 0L
        for (i in tp.indices) {
            val c = tp[i]
            val g = ((c shr 16 and 255) * 30 + (c shr 8 and 255) * 59 + (c and 255) * 11) / 100
            tg[i] = g
            tSum += g
        }
        val tMean = tSum.toDouble() / tg.size

        val sp = IntArray(screen.width * screen.height)
        screen.getPixels(sp, 0, screen.width, 0, 0, screen.width, screen.height)

        var best = Int.MAX_VALUE
        var bx = 0
        var by = 0
        val maxX = screen.width - tw
        val maxY = screen.height - th

        for (y in 0..maxY step step) {
            for (x in 0..maxX step step) {
                var sum = 0L
                var diff = 0L
                var i = 0
                while (i < tg.size) {
                    val ry = i / tw
                    val rx = i - ry * tw
                    val c = sp[(y + ry) * screen.width + (x + rx)]
                    val g = ((c shr 16 and 255) * 30 + (c shr 8 and 255) * 59 + (c and 255) * 11) / 100
                    diff += abs(g - tg[i])
                    sum += g
                    i += 4
                }
                val sampled = (tg.size + 3) / 4
                val avg = sum.toDouble() / sampled
                val meanPenalty = abs(avg - tMean) * 0.5
                val error = (diff.toDouble() / sampled + meanPenalty).toInt()
                if (error < best) {
                    best = error
                    bx = x
                    by = y
                }
            }
        }
        val score = (100 - best.coerceAtMost(100))
        val cx = bx + tw / 2f
        val cy = by + th / 2f
        return MatchResult(score >= threshold, cx, cy, score)
    }

    private fun scale(b: Bitmap, factor: Float): Bitmap {
        if (factor >= .999f) return b
        return Bitmap.createScaledBitmap(
            b,
            max(1, (b.width * factor).toInt()),
            max(1, (b.height * factor).toInt()),
            true
        )
    }
}
