package com.nextystudio.nextyimageclick

import android.app.Activity
import android.content.Intent
import android.graphics.BitmapFactory
import android.os.Bundle
import android.provider.Settings as AndroidSettings
import android.widget.*
import android.view.Gravity
import android.view.ViewGroup
import java.io.ByteArrayOutputStream

class MainActivity : Activity() {
    private lateinit var status: TextView
    private lateinit var targetPreview: ImageView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        buildUi()
    }

    private fun buildUi() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(28, 22, 28, 22)
            setBackgroundColor(0xFF111111.toInt())
        }

        val title = TextView(this).apply {
            text = "NEXTY IMAGE CLICK"
            textSize = 24f
            setTextColor(0xFFFFFFFF.toInt())
            gravity = Gravity.CENTER
        }
        root.addView(title, LinearLayout.LayoutParams(-1, 60))

        targetPreview = ImageView(this).apply {
            scaleType = ImageView.ScaleType.CENTER_INSIDE
            setBackgroundColor(0xFF202020.toInt())
        }
        root.addView(targetPreview, LinearLayout.LayoutParams(-1, 220))

        val choose = Button(this).apply {
            text = "🖼 PILIH GAMBAR TARGET"
            setOnClickListener {
                startActivityForResult(Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
                    type = "image/*"
                    addCategory(Intent.CATEGORY_OPENABLE)
                }, 10)
            }
        }
        root.addView(choose)

        val threshold = SeekBar(this).apply {
            max = 30
            progress = (SettingsCompat.threshold(this@MainActivity) - 70).coerceIn(0, 30)
        }
        val thresholdLabel = TextView(this).apply {
            setTextColor(0xFFFFFFFF.toInt())
            text = "Akurasi: ${70 + threshold.progress}%"
        }
        threshold.setOnSeekBarChangeListener(object: SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar?, p: Int, fromUser: Boolean) {
                thresholdLabel.text = "Akurasi: ${70 + p}%"
                SettingsCompat.saveThreshold(this@MainActivity, 70 + p)
            }
            override fun onStartTrackingTouch(s: SeekBar?) {}
            override fun onStopTrackingTouch(s: SeekBar?) {}
        })
        root.addView(thresholdLabel)
        root.addView(threshold)

        val access = Button(this).apply {
            text = "⚙ AKTIFKAN ACCESSIBILITY"
            setOnClickListener { startActivity(Intent(AndroidSettings.ACTION_ACCESSIBILITY_SETTINGS)) }
        }
        root.addView(access)

        val start = Button(this).apply {
            text = "▶ TAMPILKAN PANEL DI GAME"
            setOnClickListener {
                NextyAccessibilityService.get()?.showPanel()
                    ?: Toast.makeText(this@MainActivity, "Aktifkan Accessibility dulu.", Toast.LENGTH_SHORT).show()
            }
        }
        root.addView(start)

        status = TextView(this).apply {
            setTextColor(0xFFBBBBBB.toInt())
            text = "Target: ${if (SettingsCompat.targetExists(this@MainActivity)) "siap" else "belum dipilih"}"
        }
        root.addView(status)

        setContentView(root)
        refreshPreview()
    }

    private fun refreshPreview() {
        val f = getFileStreamPath("target.png")
        if (f.exists()) targetPreview.setImageBitmap(BitmapFactory.decodeFile(f.absolutePath))
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == 10 && resultCode == RESULT_OK) {
            data?.data?.let { uri ->
                contentResolver.openInputStream(uri)?.use { input ->
                    val bytes = input.readBytes()
                    SettingsCompat.saveTarget(this, bytes)
                }
                refreshPreview()
                status.text = "Target: siap"
            }
        }
    }
}

private object SettingsCompat {
    fun targetExists(c: android.content.Context) = Settings.targetExists(c)
    fun saveTarget(c: android.content.Context, b: ByteArray) = Settings.saveTarget(c, b)
    fun threshold(c: android.content.Context) = Settings.threshold(c)
    fun saveThreshold(c: android.content.Context, v: Int) = Settings.saveThreshold(c, v)
}
