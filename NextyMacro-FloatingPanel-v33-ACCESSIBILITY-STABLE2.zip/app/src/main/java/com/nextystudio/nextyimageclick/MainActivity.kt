package com.nextystudio.nextyimageclick

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.provider.Settings as AndroidSettings
import android.graphics.Color
import android.view.Gravity
import android.widget.*

class MainActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        // Keep the launcher Activity lightweight and independent from the
        // Accessibility service lifecycle. Enabling/disabling the service must
        // never make this Activity crash or close on its own.
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER; setPadding(28,28,28,28); setBackgroundColor(Color.rgb(244,243,247)) }
        root.addView(TextView(this).apply { text = "NEXTY MACRO"; textSize = 28f; setTextColor(Color.rgb(40,40,40)); gravity = Gravity.CENTER; setPadding(0,0,0,18) })
        root.addView(TextView(this).apply { text = "Editor macro berada di floating panel di atas game/aplikasi target.\nTidak perlu memasukkan X/Y manual."; textSize = 15f; gravity = Gravity.CENTER; setTextColor(Color.DKGRAY); setPadding(0,0,0,20) })
        root.addView(Button(this).apply { text = "1. AKTIFKAN ACCESSIBILITY"; setOnClickListener { startActivity(Intent(AndroidSettings.ACTION_ACCESSIBILITY_SETTINGS)) } })
        root.addView(Button(this).apply { text = "2. TAMPILKAN FLOATING PANEL"; setOnClickListener { NextyAccessibilityService.get()?.showPanel() ?: Toast.makeText(this@MainActivity, "Aktifkan Accessibility dulu.", Toast.LENGTH_SHORT).show() } })
        root.addView(TextView(this).apply { text = "Setelah panel tampil, buka game. Semua tindakan, titik klik, kondisi gambar, dan loop diatur dari panel."; textSize = 13f; gravity = Gravity.CENTER; setTextColor(Color.GRAY); setPadding(0,22,0,0) })
        setContentView(root)
    }
}
