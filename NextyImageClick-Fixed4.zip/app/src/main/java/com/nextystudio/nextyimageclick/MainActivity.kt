package com.nextystudio.nextyimageclick

import android.app.Activity
import android.content.Intent
import android.graphics.BitmapFactory
import android.os.Bundle
import android.provider.Settings as AndroidSettings
import android.view.Gravity
import android.widget.*

class MainActivity : Activity() {
    private lateinit var status: TextView
    private lateinit var targetPreview: ImageView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        buildUi()
    }

    private fun buildUi() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(24, 16, 24, 16)
            setBackgroundColor(0xFF111111.toInt())
        }
        val title = TextView(this).apply {
            text = "NEXTY IMAGE CLICK"
            textSize = 24f
            setTextColor(0xFFFFFFFF.toInt())
            gravity = Gravity.CENTER
        }
        root.addView(title, LinearLayout.LayoutParams(-1, 58))

        targetPreview = ImageView(this).apply {
            scaleType = ImageView.ScaleType.CENTER_INSIDE
            setBackgroundColor(0xFF202020.toInt())
        }
        root.addView(targetPreview, LinearLayout.LayoutParams(-1, 180))

        val choose = Button(this).apply {
            text = "🖼 PILIH GAMBAR TARGET"
            setOnClickListener {
                startActivityForResult(Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
                    type = "image/*"
                    addCategory(Intent.CATEGORY_OPENABLE)
                }, 10)
            }
        }
        root.addView(choose)

        val thresholdLabel = TextView(this).apply { setTextColor(0xFFFFFFFF.toInt()) }
        val threshold = SeekBar(this).apply {
            max = 30
            progress = (Settings.threshold(this@MainActivity) - 70).coerceIn(0, 30)
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(s: SeekBar?, p: Int, fromUser: Boolean) {
                    val v = 70 + p
                    thresholdLabel.text = "Match Score: $v%"
                    Settings.saveThreshold(this@MainActivity, v)
                }
                override fun onStartTrackingTouch(s: SeekBar?) {}
                override fun onStopTrackingTouch(s: SeekBar?) {}
            })
        }
        root.addView(thresholdLabel)
        root.addView(threshold)

        val intervalLabel = TextView(this).apply { setTextColor(0xFFFFFFFF.toInt()) }
        val interval = SeekBar(this).apply {
            max = 29
            progress = ((Settings.interval(this@MainActivity) - 100L) / 100L).toInt().coerceIn(0, 29)
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(s: SeekBar?, p: Int, fromUser: Boolean) {
                    val v = 100L + p * 100L
                    intervalLabel.text = "Scan Rate: ${v}ms"
                    Settings.saveInterval(this@MainActivity, v)
                }
                override fun onStartTrackingTouch(s: SeekBar?) {}
                override fun onStopTrackingTouch(s: SeekBar?) {}
            })
        }
        root.addView(intervalLabel)
        root.addView(interval)

        val access = Button(this).apply {
            text = "⚙ AKTIFKAN ACCESSIBILITY"
            setOnClickListener { startActivity(Intent(AndroidSettings.ACTION_ACCESSIBILITY_SETTINGS)) }
        }
        root.addView(access)

        val start = Button(this).apply {
            text = "▶ TAMPILKAN PANEL DI GAME"
            setOnClickListener {
                NextyAccessibilityService.get()?.showPanel()
                    ?: Toast.makeText(this@MainActivity, "Aktifkan Accessibility dulu.", Toast.LENGTH_SHORT).show()
            }
        }
        root.addView(start)

        status = TextView(this).apply {
            setTextColor(0xFFBBBBBB.toInt())
            text = "Target: ${if (Settings.targetExists(this@MainActivity)) "siap" else "belum dipilih"}"
        }
        root.addView(status)
        setContentView(root)
        refreshPreview()
        thresholdLabel.text = "Match Score: ${Settings.threshold(this)}%"
        intervalLabel.text = "Scan Rate: ${Settings.interval(this)}ms"
    }

    private fun refreshPreview() {
        val f = getFileStreamPath("target.png")
        if (f.exists()) targetPreview.setImageBitmap(BitmapFactory.decodeFile(f.absolutePath))
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == 10 && resultCode == RESULT_OK) {
            data?.data?.let { uri ->
                contentResolver.openInputStream(uri)?.use { input -> Settings.saveTarget(this, input.readBytes()) }
                refreshPreview()
                status.text = "Target: siap"
            }
        }
    }
}
