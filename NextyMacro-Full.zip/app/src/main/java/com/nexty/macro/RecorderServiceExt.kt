package com.nexty.macro

fun NextyAccessibilityService.startRecorder(macro: Macro, refresh: () -> Unit) {
    RecorderOverlay(this, { action ->
        macro.actions += action
        refresh()
        when (action.type) {
            ActionType.TAP -> Unit
            ActionType.SWIPE -> Unit
            else -> Unit
        }
    }, {
        refresh()
    }).show()
}
