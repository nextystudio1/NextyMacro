package com.nextystudio.nextymacro

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

object Store {
    private const val PREF = "nexty_macro"
    private const val ACTIONS = "actions"
    private const val CONDITIONS = "conditions"

    fun loadActions(ctx: Context): MutableList<MacroAction> {
        val out = mutableListOf<MacroAction>()
        val a = ctx.getSharedPreferences(PREF, 0).getString(ACTIONS, "[]") ?: "[]"
        val arr = JSONArray(a)
        for (i in 0 until arr.length()) {
            val o = arr.getJSONObject(i)
            out += MacroAction(o.getLong("id"), o.getString("name"), o.getInt("x"), o.getInt("y"),
                if (o.isNull("conditionId")) null else o.getLong("conditionId"), o.optLong("delayMs", 0))
        }
        return out
    }

    fun saveActions(ctx: Context, list: List<MacroAction>) {
        val arr = JSONArray()
        list.forEach { a ->
            arr.put(JSONObject().apply {
                put("id", a.id); put("name", a.name); put("x", a.x); put("y", a.y)
                if (a.conditionId == null) put("conditionId", JSONObject.NULL) else put("conditionId", a.conditionId)
                put("delayMs", a.delayMs)
            })
        }
        ctx.getSharedPreferences(PREF, 0).edit().putString(ACTIONS, arr.toString()).apply()
    }

    fun loadConditions(ctx: Context): MutableList<Condition> {
        val out = mutableListOf<Condition>()
        val s = ctx.getSharedPreferences(PREF, 0).getString(CONDITIONS, "[]") ?: "[]"
        val arr = JSONArray(s)
        for (i in 0 until arr.length()) {
            val o = arr.getJSONObject(i)
            out += Condition(o.getLong("id"), o.getString("name"), o.getString("imagePath"), o.optInt("threshold", 88))
        }
        return out
    }

    fun saveConditions(ctx: Context, list: List<Condition>) {
        val arr = JSONArray()
        list.forEach { c -> arr.put(JSONObject().apply {
            put("id", c.id); put("name", c.name); put("imagePath", c.imagePath); put("threshold", c.threshold)
        }) }
        ctx.getSharedPreferences(PREF, 0).edit().putString(CONDITIONS, arr.toString()).apply()
    }
}
