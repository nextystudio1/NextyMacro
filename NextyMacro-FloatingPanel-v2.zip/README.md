# NextyMacro Floating Panel v2

Floating compact bubble + collapsible panel. Tap the round N bubble to open the panel; tap X to collapse it back to the bubble. Drag the bubble to reposition it. The macro editor stays as an overlay above the target game/app.
