Nexty Macro v13

This build keeps the v12 canonical tap implementation and fixes the click-point picker:
- small exact-center crosshair marker
- saved point is the marker's actual on-screen center
- live TAP X,Y coordinate shown while moving the marker
- no change to the working canonical accessibility tap
- existing per-action delete (×) remains available


## v14 changes
- Click point picker uses a true full-screen accessibility overlay and no longer clamps the marker above the bottom controls.
- Marker coordinates are saved from getLocationOnScreen() at the marker center.
- Canonical tap gesture path from v13 is preserved.
