package com.nextystudio.nextyimageclick

import android.graphics.Bitmap
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min

data class MatchResult(val found: Boolean, val x: Float = 0f, val y: Float = 0f, val score: Int = 0)

object ImageMatcher {
    /** Template matching using normalized grayscale mean absolute error. */
    fun find(screen: Bitmap, target: Bitmap, threshold: Int): MatchResult {
        if (screen.width < 1 || screen.height < 1 || target.width < 4 || target.height < 4) return MatchResult(false)

        val factor = min(1f, min(100f / target.width, 100f / target.height))
        val t = if (factor < 0.999f) Bitmap.createScaledBitmap(target, max(4, (target.width * factor).toInt()), max(4, (target.height * factor).toInt()), true) else target
        if (t.width > screen.width || t.height > screen.height) { if (t !== target) t.recycle(); return MatchResult(false) }

        val tw = t.width
        val th = t.height
        val tp = IntArray(tw * th)
        t.getPixels(tp, 0, tw, 0, 0, tw, th)
        val tg = IntArray(tp.size)
        for (i in tp.indices) {
            val c = tp[i]
            tg[i] = ((c shr 16 and 255) * 30 + (c shr 8 and 255) * 59 + (c and 255) * 11) / 100
        }

        val sp = IntArray(screen.width * screen.height)
        screen.getPixels(sp, 0, screen.width, 0, 0, screen.width, screen.height)
        val sampleStep = 2
        var bestError = Double.POSITIVE_INFINITY
        var bx = 0
        var by = 0
        val maxX = screen.width - tw
        val maxY = screen.height - th

        for (y in 0..maxY step sampleStep) {
            for (x in 0..maxX step sampleStep) {
                var diff = 0L
                var count = 0
                var i = 0
                while (i < tg.size) {
                    val ry = i / tw
                    val rx = i - ry * tw
                    val c = sp[(y + ry) * screen.width + (x + rx)]
                    val g = ((c shr 16 and 255) * 30 + (c shr 8 and 255) * 59 + (c and 255) * 11) / 100
                    diff += abs(g - tg[i])
                    count++
                    i += 2
                }
                val error = diff.toDouble() / (count.coerceAtLeast(1) * 255.0) * 100.0
                if (error < bestError) { bestError = error; bx = x; by = y }
            }
        }

        if (t !== target) t.recycle()
        val score = (100.0 - bestError).coerceIn(0.0, 100.0).toInt()
        return MatchResult(score >= threshold, bx + tw / 2f, by + th / 2f, score)
    }
}
