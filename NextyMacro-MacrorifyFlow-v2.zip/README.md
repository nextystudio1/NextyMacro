# Nexty Macro – Macrorify-style flow

Versi ini mengubah cara kerja Nexty menjadi **macro berurutan**.

## Alur utama

`Tindakan 1 → Tindakan 2 → ... → Tindakan N → kembali ke Tindakan 1`

Contoh:

1. Kondisi: **Gambar Muncul**
2. Tindakan: **Klik hasil gambar**
3. Delay 500 ms
4. Klik koordinat
5. ...
12. Tindakan terakhir

Setelah tindakan 12 selesai, satu putaran selesai. Jika Loop aktif, macro kembali ke tindakan 1.

## Deteksi gambar

- Pilih gambar target.
- Pilih potongan/area pencarian dengan drag.
- Match Score 50–100%.
- Scan Rate 100–3000 ms.
- Kondisi `Gambar Muncul` menunggu sampai gambar ditemukan di area tersebut.
- `Klik hasil gambar` menggunakan posisi gambar yang benar-benar ditemukan, bukan koordinat tetap.

## Loop

- Sekali
- Ulangi jumlah tertentu
- Tanpa batas

## Tindakan saat ini

- Kondisi: Gambar Muncul
- Klik hasil gambar
- Klik koordinat
- Delay

## Build

Workflow GitHub Actions `Build Nexty Image Click` membangun `app-debug.apk` dan mengunggahnya sebagai artifact.
