Nexty Macro v13

This build keeps the v12 canonical tap implementation and fixes the click-point picker:
- small exact-center crosshair marker
- saved point is the marker's actual on-screen center
- live TAP X,Y coordinate shown while moving the marker
- no change to the working canonical accessibility tap
- existing per-action delete (×) remains available
