# Nexty Macro — Macrorify-style foundation

Features included:
- Macro library
- Create / edit / delete macros
- Tap actions
- Swipe actions
- Delay actions
- Back / Home / Recents
- Text insertion into focused editable fields
- Repeat count
- AccessibilityService gesture playback
- Full-screen recorder overlay for tap/swipe capture
- Per-action coordinates and timing
- GitHub Actions APK build

Important:
- Android Accessibility must be enabled before playback/recording.
- The recorder overlay forwards recorded gestures through Accessibility.
- Image recognition, OCR, conditional branches, loops, variables and template matching are intentionally not included in this first build because those require a separate screen-capture/image-processing subsystem.
