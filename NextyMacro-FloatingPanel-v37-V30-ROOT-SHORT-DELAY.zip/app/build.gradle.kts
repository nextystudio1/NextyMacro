plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.nextystudio.nextyimageclick"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.nextystudio.nextyimageclick"
        minSdk = 30
        targetSdk = 35
        versionCode = 1
        versionName = "1.0"
    }
}

kotlin {
    jvmToolchain(17)
}
