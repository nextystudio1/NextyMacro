NextyMacro v38

BASE: exact user-uploaded NextyMacro v30-PANEL-BEBAS-PINDAH.
Only Delay input/default was changed:
- default 1000 ms
- allowed range 1000-2000 ms
- existing delay values are displayed/clamped to 1000-2000 ms when edited
No Accessibility/service/panel/click/hold/condition/loop changes.
