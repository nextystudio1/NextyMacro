package com.nextystudio.nextyimageclick

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.graphics.*
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.view.*
import android.widget.*
import java.util.concurrent.Executors
import kotlin.math.roundToInt

class NextyAccessibilityService : AccessibilityService() {
    companion object { private var instance: NextyAccessibilityService?=null; fun get()=instance }
    private val main=Handler(Looper.getMainLooper())
    private val executor=Executors.newSingleThreadExecutor()
    private var panel:LinearLayout?=null
    private var panelStatus:TextView?=null
    private var running=false; private var busy=false; private var currentStep=0; private var completedLoops=0

    override fun onServiceConnected(){super.onServiceConnected();instance=this}
    override fun onDestroy(){instance=null;executor.shutdownNow();removeOverlay();super.onDestroy()}
    override fun onAccessibilityEvent(event:android.view.accessibility.AccessibilityEvent?){}
    override fun onInterrupt(){}

    fun showPanel(){
        main.post{
            if(panel!=null)return@post
            val wm=getSystemService(WINDOW_SERVICE) as WindowManager
            val p=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(12,10,12,10);setBackgroundColor(0xEE191919.toInt())}
            val title=TextView(this).apply{text="NEXTY • MACRO";textSize=15f;setTextColor(Color.WHITE);setPadding(8,4,8,6)}
            panelStatus=TextView(this).apply{text=statusText();textSize=12f;setTextColor(Color.WHITE);setPadding(8,2,8,8)}
            val start=Button(this).apply{text="▶ START";setOnClickListener{startMacro()}}
            val stop=Button(this).apply{text="■ STOP";setOnClickListener{stopMacro()}}
            val close=Button(this).apply{text="× TUTUP";setOnClickListener{removeOverlay()}}
            p.addView(title);p.addView(panelStatus);p.addView(start);p.addView(stop);p.addView(close)
            val lp=WindowManager.LayoutParams(285,-2,WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,PixelFormat.TRANSLUCENT).apply{gravity=Gravity.TOP or Gravity.END;x=12;y=80}
            title.setOnTouchListener(object:View.OnTouchListener{
                var dx=0f;var dy=0f;var sx=0;var sy=0
                override fun onTouch(v:View,e:MotionEvent):Boolean=when(e.action){
                    MotionEvent.ACTION_DOWN->{dx=e.rawX;dy=e.rawY;sx=lp.x;sy=lp.y;true}
                    MotionEvent.ACTION_MOVE->{lp.x=sx+(e.rawX-dx).roundToInt();lp.y=sy+(e.rawY-dy).roundToInt();wm.updateViewLayout(p,lp);true}
                    else->true
                }
            })
            wm.addView(p,lp);panel=p
        }
    }
    private fun statusText():String{
        val n=MacroStore.getSteps(this).size
        return if(running)"RUN • tindakan ${currentStep+1}/$n • loop ${completedLoops+1}" else "STOP • $n tindakan"
    }
    private fun updatePanel(){main.post{panelStatus?.text=statusText()}}

    // Titik klik: bulatan draggable ditempatkan langsung di atas game.
    fun startCoordinatePicker(onPicked:(PointF)->Unit){
        val wm=getSystemService(WINDOW_SERVICE) as WindowManager
        val root=FrameLayout(this).apply{setBackgroundColor(0x22000000)}
        val hint=TextView(this).apply{text="GESER BULATAN ● KE POSISI KLIK";textSize=18f;gravity=Gravity.CENTER;setTextColor(Color.WHITE);setBackgroundColor(0xAA000000.toInt());setPadding(18,12,18,12)}
        root.addView(hint,FrameLayout.LayoutParams(-2,-2,Gravity.TOP or Gravity.CENTER_HORIZONTAL).apply{topMargin=40})
        val circle=TextView(this).apply{text="●";textSize=64f;gravity=Gravity.CENTER;setTextColor(0xFFFF9F1C.toInt());setShadowLayer(8f,0f,0f,Color.BLACK);background=android.graphics.drawable.GradientDrawable().apply{shape=android.graphics.drawable.GradientDrawable.OVAL;setColor(0x55FFFFFF)}}
        val cp=FrameLayout.LayoutParams(96,96).apply{leftMargin=420;topMargin=300}
        root.addView(circle,cp)
        val buttons=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL;gravity=Gravity.CENTER}
        val cancel=Button(this).apply{text="BATAL";setOnClickListener{remove(root)}}
        val save=Button(this).apply{text="SIMPAN TITIK";setOnClickListener{
            val lp=cp as FrameLayout.LayoutParams
            val p=PointF(lp.leftMargin+lp.width/2f,lp.topMargin+lp.height/2f);remove(root);onPicked(p)
        }}
        buttons.addView(cancel,LinearLayout.LayoutParams(0,-2,1f));buttons.addView(save,LinearLayout.LayoutParams(0,-2,1f))
        root.addView(buttons,FrameLayout.LayoutParams(-1,-2,Gravity.BOTTOM))
        circle.setOnTouchListener(object:View.OnTouchListener{
            var dx=0f;var dy=0f
            override fun onTouch(v:View,e:MotionEvent):Boolean=when(e.action){
                MotionEvent.ACTION_DOWN->{val lp=cp as FrameLayout.LayoutParams;dx=e.rawX-lp.leftMargin;dy=e.rawY-lp.topMargin;true}
                MotionEvent.ACTION_MOVE->{val lp=cp as FrameLayout.LayoutParams;lp.leftMargin=(e.rawX-dx).roundToInt().coerceIn(0,(root.width-lp.width).coerceAtLeast(0));lp.topMargin=(e.rawY-dy).roundToInt().coerceIn(0,(root.height-lp.height-100).coerceAtLeast(0));v.layoutParams=lp;v.requestLayout();true}
                else->true
            }
        })
        wm.addView(root,fullOverlayParams())
    }

    // Kondisi gambar: ambil screenshot GAME, lalu user potong langsung di screenshot tersebut.
    fun startConditionPicker(onSaved:(ByteArray,RectF)->Unit){
        if(Build.VERSION.SDK_INT<30){toast("Android 11+ diperlukan.");return}
        takeScreenshot(0,executor,object:TakeScreenshotCallback{
            override fun onSuccess(result:ScreenshotResult){
                try{
                    val hw=result.hardwareBuffer
                    val b=Bitmap.wrapHardwareBuffer(hw,result.colorSpace);hw.close()
                    if(b==null){toast("Gagal mengambil screenshot.");return}
                    val bmp=b.copy(Bitmap.Config.ARGB_8888,false);b.recycle()
                    main.post{showCropOverlay(bmp,onSaved)}
                }catch(_:Throwable){toast("Gagal mengambil screenshot.")}
            }
            override fun onFailure(errorCode:Int){toast("Screenshot gagal: $errorCode")}
        })
    }

    private fun showCropOverlay(bitmap:Bitmap,onSaved:(ByteArray,RectF)->Unit){
        val wm=getSystemService(WINDOW_SERVICE) as WindowManager
        val root=FrameLayout(this).apply{setBackgroundColor(Color.BLACK)}
        val image=ImageView(this).apply{setImageBitmap(bitmap);scaleType=ImageView.ScaleType.FIT_XY}
        root.addView(image,FrameLayout.LayoutParams(-1,-1))
        val selector=CropSelector(this).apply{setBitmapSize(bitmap.width,bitmap.height)}
        root.addView(selector,FrameLayout.LayoutParams(-1,-1))
        val top=TextView(this).apply{text="POTONG GAMBAR KONDISI • tarik area pada game";textSize=17f;gravity=Gravity.CENTER;setTextColor(Color.WHITE);setBackgroundColor(0xAA000000.toInt());setPadding(15,10,15,10)}
        root.addView(top,FrameLayout.LayoutParams(-1,-2,Gravity.TOP))
        val row=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL;setPadding(8,5,8,5);setBackgroundColor(0xEE111111.toInt())}
        val cancel=Button(this).apply{text="BATAL";setOnClickListener{remove(root);bitmap.recycle()}}
        val save=Button(this).apply{text="SIMPAN GAMBAR";setOnClickListener{
            val r=selector.selection()
            if(r.width()<10f||r.height()<10f){toast("Area terlalu kecil.");return@setOnClickListener}
            try{
                val left=r.left.toInt().coerceIn(0,bitmap.width-1);val topy=r.top.toInt().coerceIn(0,bitmap.height-1)
                val right=r.right.toInt().coerceIn(left+1,bitmap.width);val bottom=r.bottom.toInt().coerceIn(topy+1,bitmap.height)
                val crop=Bitmap.createBitmap(bitmap,left,topy,right-left,bottom-topy)
                val out=java.io.ByteArrayOutputStream();crop.compress(Bitmap.CompressFormat.PNG,100,out);crop.recycle()
                remove(root);onSaved(out.toByteArray(),RectF(left.toFloat(),topy.toFloat(),right.toFloat(),bottom.toFloat()));bitmap.recycle()
            }catch(_:Throwable){toast("Gagal memotong gambar.")}
        }}
        row.addView(cancel,LinearLayout.LayoutParams(0,-2,1f));row.addView(save,LinearLayout.LayoutParams(0,-2,1f))
        root.addView(row,FrameLayout.LayoutParams(-1,-2,Gravity.BOTTOM))
        wm.addView(root,fullOverlayParams())
    }

    private fun fullOverlayParams()=WindowManager.LayoutParams(-1,-1,WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,PixelFormat.TRANSLUCENT)
    private fun remove(v:View){try{(getSystemService(WINDOW_SERVICE) as WindowManager).removeView(v)}catch(_:Throwable){}}

    private class CropSelector(c:android.content.Context):View(c){
        private val paint=Paint(Paint.ANTI_ALIAS_FLAG).apply{style=Paint.Style.STROKE;strokeWidth=5f;color=Color.YELLOW}
        private var sx=0f;private var sy=0f;private var ex=0f;private var ey=0f;private var active=false
        private var bw=1;private var bh=1
        fun setBitmapSize(w:Int,h:Int){bw=w;bh=h}
        fun selection():RectF{
            val vw=width.toFloat().coerceAtLeast(1f);val vh=height.toFloat().coerceAtLeast(1f)
            return RectF(minOf(sx,ex)*bw/vw,minOf(sy,ey)*bh/vh,maxOf(sx,ex)*bw/vw,maxOf(sy,ey)*bh/vh)
        }
        override fun onDraw(canvas:Canvas){super.onDraw(canvas);if(active){canvas.drawRect(minOf(sx,ex),minOf(sy,ey),maxOf(sx,ex),maxOf(sy,ey),paint)}}
        override fun onTouchEvent(e:MotionEvent):Boolean=when(e.action){
            MotionEvent.ACTION_DOWN->{sx=e.x;sy=e.y;ex=e.x;ey=e.y;active=true;invalidate();true}
            MotionEvent.ACTION_MOVE->{ex=e.x;ey=e.y;invalidate();true}
            MotionEvent.ACTION_UP->{ex=e.x;ey=e.y;invalidate();true}
            else->true
        }
    }

    fun startMacro(){
        if(running)return
        val steps=MacroStore.getSteps(this)
        if(steps.isEmpty()){toast("Tambahkan tindakan dulu.");return}
        if(Build.VERSION.SDK_INT<30){toast("Android 11+ diperlukan.");return}
        val bad=steps.withIndex().firstOrNull{it.value.conditionImage&&(!Settings.stepTargetExists(this,it.value.id)||!it.value.hasRegion())}
        if(bad!=null){toast("Kondisi tindakan #${bad.index+1} belum lengkap.");return}
        running=true;busy=false;currentStep=0;completedLoops=0;updatePanel();executeCurrentStep()
    }
    fun stopMacro(){running=false;busy=false;main.removeCallbacksAndMessages(null);updatePanel();toast("Macro dihentikan")}

    private fun executeCurrentStep(){
        if(!running)return
        val steps=MacroStore.getSteps(this)
        if(steps.isEmpty()){stopMacro();return}
        if(currentStep>=steps.size){
            completedLoops++
            val mode=MacroStore.loopMode(this)
            if(mode==0||(mode==1&&completedLoops>=MacroStore.loopCount(this))){running=false;updatePanel();toast("Selesai $completedLoops putaran");return}
            currentStep=0;updatePanel();main.post{executeCurrentStep()};return
        }
        updatePanel()
        val step=steps[currentStep]
        if(step.conditionImage){waitForCondition(step);return}
        performAction(step)
    }

    private fun performAction(step:MacroStep){
        if(!running)return
        when(step.type){
            StepType.DELAY->main.postDelayed({if(running){currentStep++;executeCurrentStep()}},step.delayMs.coerceAtLeast(0L))
            StepType.CLICK_COORD->performClick(PointF(step.x,step.y)){currentStep++;executeCurrentStep()}
        }
    }

    private fun waitForCondition(step:MacroStep){
        if(!running||busy)return
        busy=true
        takeScreenshot(0,executor,object:TakeScreenshotCallback{
            override fun onSuccess(result:ScreenshotResult){
                try{
                    val hw=result.hardwareBuffer
                    val full=Bitmap.wrapHardwareBuffer(hw,result.colorSpace);hw.close()
                    if(full==null){retryCondition(step);return}
                    val screen=full.copy(Bitmap.Config.ARGB_8888,false);full.recycle()
                    executor.execute{
                        var crop:Bitmap?=null;var target:Bitmap?=null
                        try{
                            target=BitmapFactory.decodeFile(Settings.stepTargetPath(this@NextyAccessibilityService,step.id))
                            if(target==null){retryCondition(step);return@execute}
                            val left=step.regionL.toInt().coerceIn(0,screen.width-1)
                            val top=step.regionT.toInt().coerceIn(0,screen.height-1)
                            val right=step.regionR.toInt().coerceIn(left+1,screen.width)
                            val bottom=step.regionB.toInt().coerceIn(top+1,screen.height)
                            crop=Bitmap.createBitmap(screen,left,top,right-left,bottom-top)
                            val match=ImageMatcher.find(crop!!,target!!,step.conditionThreshold)
                            if(match.found){busy=false;main.post{if(running){currentStep++;executeCurrentStep()}}}
                            else retryCondition(step)
                        }catch(_:Throwable){retryCondition(step)}
                        finally{crop?.recycle();target?.recycle();screen.recycle()}
                    }
                }catch(_:Throwable){retryCondition(step)}
            }
            override fun onFailure(errorCode:Int){retryCondition(step)}
        })
    }
    private fun retryCondition(step:MacroStep){busy=false;if(running)main.postDelayed({waitForCondition(step)},step.conditionInterval.coerceIn(100L,3000L))}

    private fun performClick(p:PointF,done:()->Unit){
        val path=Path().apply{moveTo(p.x,p.y)}
        val duration=if(Settings.clickMode(this)==2)650L else 70L
        val g=GestureDescription.Builder().addStroke(GestureDescription.StrokeDescription(path,0,duration)).build()
        dispatchGesture(g,object:GestureResultCallback(){
            override fun onCompleted(gd:GestureDescription?){main.postDelayed(done,Settings.cooldown(this@NextyAccessibilityService).coerceAtLeast(0L))}
            override fun onCancelled(gd:GestureDescription?){main.postDelayed(done,100L)}
        },null)
    }
    private fun toast(s:String)=main.post{Toast.makeText(this,s,Toast.LENGTH_SHORT).show()}
    private fun removeOverlay(){main.post{stopMacro();val wm=getSystemService(WINDOW_SERVICE) as WindowManager;panel?.let{try{wm.removeView(it)}catch(_:Throwable){}};panel=null;panelStatus=null}}
}
