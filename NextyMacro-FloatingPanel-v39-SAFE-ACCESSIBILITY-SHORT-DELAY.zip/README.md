NextyMacro v39
Based directly on the uploaded v30. Delay is limited to 1000-2000 ms. Accessibility configuration is made lighter/defensive to reduce service startup crashes: window-state events only, no window-content retrieval, default flags. Gesture and screenshot capabilities remain enabled.
