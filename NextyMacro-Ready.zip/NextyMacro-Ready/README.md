# Nexty Macro Ready
Basic Android macro app: Accessibility, TAP, SWIPE, DELAY, BACK, HOME, repeat, and GitHub Actions APK build.
