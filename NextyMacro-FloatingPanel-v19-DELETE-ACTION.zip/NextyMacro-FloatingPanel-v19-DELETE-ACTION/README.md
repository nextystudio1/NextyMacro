# NextyMacro v19 - Action Delete Visible

Perubahan:
- Tombol X panel tetap untuk menutup panel.
- Setiap tindakan sekarang punya tombol X MERAH kecil sendiri di kanan judul tindakan.
- Tombol naik/turun juga dibuat kecil.
- Judul tindakan dipaksa terlihat satu baris.
- Fungsi klik, kondisi, fullscreen picker, dan macro tidak diubah.

Workflow ZIP: NextyMacro-FloatingPanel-v19-DELETE-ACTION.zip
