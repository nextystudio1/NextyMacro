package com.nextystudio.nextyimageclick

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.graphics.Bitmap
import android.graphics.Path
import android.graphics.PointF
import android.graphics.RectF
import android.content.Intent
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.view.*
import android.widget.*
import java.util.concurrent.Executors
import kotlin.math.roundToInt

class NextyAccessibilityService : AccessibilityService() {
    companion object {
        private var instance: NextyAccessibilityService? = null
        fun get(): NextyAccessibilityService? = instance
    }
    private val main=Handler(Looper.getMainLooper())
    private val executor=Executors.newSingleThreadExecutor()
    private var panel:LinearLayout?=null
    private var panelStatus:TextView?=null
    private var running=false
    private var busy=false
    private var currentStep=0
    private var completedLoops=0

    override fun onServiceConnected(){super.onServiceConnected();instance=this}
    override fun onDestroy(){instance=null;executor.shutdownNow();removeOverlay();super.onDestroy()}
    override fun onAccessibilityEvent(event:android.view.accessibility.AccessibilityEvent?){}
    override fun onInterrupt(){}

    fun showPanel(){
        main.post{
            if(panel!=null)return@post
            val wm=getSystemService(WINDOW_SERVICE) as WindowManager
            val p=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(12,10,12,10);setBackgroundColor(0xEE191919.toInt())}
            val title=TextView(this).apply{text="NEXTY • MACRO";textSize=15f;setTextColor(0xFFFFFFFF.toInt());setPadding(8,4,8,6)}
            panelStatus=TextView(this).apply{text=statusText();textSize=12f;setTextColor(0xFFFFFFFF.toInt());setPadding(8,2,8,8)}
            val start=Button(this).apply{text="▶ START";setOnClickListener{startMacro()}}
            val stop=Button(this).apply{text="■ STOP";setOnClickListener{stopMacro()}}
            val close=Button(this).apply{text="× TUTUP";setOnClickListener{removeOverlay()}}
            p.addView(title);p.addView(panelStatus);p.addView(start);p.addView(stop);p.addView(close)
            val lp=WindowManager.LayoutParams(285,WindowManager.LayoutParams.WRAP_CONTENT,WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,android.graphics.PixelFormat.TRANSLUCENT).apply{gravity=Gravity.TOP or Gravity.END;x=12;y=80}
            title.setOnTouchListener(object:View.OnTouchListener{
                var dx=0f;var dy=0f;var sx=0;var sy=0
                override fun onTouch(v:View,e:MotionEvent):Boolean{when(e.action){MotionEvent.ACTION_DOWN->{dx=e.rawX;dy=e.rawY;sx=lp.x;sy=lp.y;return true};MotionEvent.ACTION_MOVE->{lp.x=sx+(e.rawX-dx).roundToInt();lp.y=sy+(e.rawY-dy).roundToInt();wm.updateViewLayout(p,lp);return true};MotionEvent.ACTION_UP->return true};return false}
            })
            wm.addView(p,lp);panel=p
        }
    }
    private fun statusText():String{
        val n=MacroStore.getSteps(this).size
        return if(running)"RUN • tindakan ${currentStep+1}/$n • loop ${completedLoops+1}" else "STOP • $n tindakan"
    }
    private fun updatePanel(){main.post{panelStatus?.text=statusText()}}

    fun startRegionPicker(){
        val wm=getSystemService(WINDOW_SERVICE) as WindowManager
        val overlay=FrameLayout(this).apply{setBackgroundColor(0x33000000)}
        val hint=TextView(this).apply{text="DRAG area pencarian\nlepaskan untuk menyimpan";textSize=19f;gravity=Gravity.CENTER;setTextColor(0xFFFFFFFF.toInt());setBackgroundColor(0xAA000000.toInt());setPadding(25,18,25,18)}
        overlay.addView(hint,FrameLayout.LayoutParams(-2,-2,Gravity.CENTER))
        var sx=0f;var sy=0f
        overlay.setOnTouchListener{_,e->when(e.action){
            MotionEvent.ACTION_DOWN->{sx=e.rawX;sy=e.rawY;hint.visibility=View.INVISIBLE;true}
            MotionEvent.ACTION_UP->{val r=RectF(minOf(sx,e.rawX),minOf(sy,e.rawY),maxOf(sx,e.rawX),maxOf(sy,e.rawY));if(r.width()>=20&&r.height()>=20)Settings.saveRegion(this,r);try{wm.removeView(overlay)}catch(_:Throwable){};Toast.makeText(this,if(r.width()>=20&&r.height()>=20)"Area tersimpan" else "Area terlalu kecil",Toast.LENGTH_SHORT).show();true}
            else->true
        }}
        wm.addView(overlay,WindowManager.LayoutParams(-1,-1,WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,android.graphics.PixelFormat.TRANSLUCENT))
    }

    fun startCoordinatePicker(onPicked:(PointF)->Unit){
        val wm=getSystemService(WINDOW_SERVICE) as WindowManager
        val pick=FrameLayout(this).apply{setBackgroundColor(0x22000000)}
        val label=TextView(this).apply{text="KETUK KOORDINAT\nuntuk tindakan";textSize=23f;gravity=Gravity.CENTER;setTextColor(0xFFFFFFFF.toInt());setBackgroundColor(0xAA000000.toInt());setPadding(25,18,25,18)}
        pick.addView(label,FrameLayout.LayoutParams(-2,-2,Gravity.CENTER))
        pick.setOnTouchListener{_,e->if(e.action==MotionEvent.ACTION_UP){val p=PointF(e.rawX,e.rawY);try{wm.removeView(pick)}catch(_:Throwable){};onPicked(p);true}else true}
        wm.addView(pick,WindowManager.LayoutParams(-1,-1,WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,android.graphics.PixelFormat.TRANSLUCENT))
    }

    fun startMacro(){
        if(running)return
        val steps=MacroStore.getSteps(this)
        if(steps.isEmpty()){toast("Tambahkan tindakan dulu.");return}
        if(Build.VERSION.SDK_INT<30){toast("Android 11+ diperlukan.");return}
        val bad=steps.withIndex().firstOrNull{it.value.conditionImage&&!Settings.stepTargetExists(this,it.value.id)}
        if(bad!=null){toast("Gambar kondisi tindakan #${bad.index+1} belum dipilih.");return}
        running=true;busy=false;currentStep=0;completedLoops=0;updatePanel();executeCurrentStep()
    }
    fun stopMacro(){running=false;busy=false;main.removeCallbacksAndMessages(null);updatePanel();toast("Macro dihentikan")}

    private fun executeCurrentStep(){
        if(!running)return
        val steps=MacroStore.getSteps(this)
        if(steps.isEmpty()){stopMacro();return}
        if(currentStep>=steps.size){
            completedLoops++
            val mode=MacroStore.loopMode(this)
            if(mode==0||(mode==1&&completedLoops>=MacroStore.loopCount(this))){
                running=false;updatePanel();toast("Selesai $completedLoops putaran");return
            }
            currentStep=0;updatePanel();main.post{executeCurrentStep()};return
        }
        updatePanel()
        val step=steps[currentStep]
        if(step.conditionImage){waitForCondition(step);return}
        performAction(step)
    }

    private fun performAction(step:MacroStep){
        if(!running)return
        when(step.type){
            StepType.DELAY->{main.postDelayed({if(running){currentStep++;executeCurrentStep()}},step.delayMs.coerceAtLeast(0L))}
            StepType.CLICK_COORD,StepType.CLICK_DETECTED->{performClick(PointF(step.x+Settings.offsetX(this),step.y+Settings.offsetY(this))){currentStep++;executeCurrentStep()}}
            StepType.CONDITION_IMAGE->{currentStep++;executeCurrentStep()}
        }
    }

    private fun waitForCondition(step:MacroStep){
        if(!running||busy)return
        busy=true
        takeScreenshot(0,executor,object:TakeScreenshotCallback{
            override fun onSuccess(result:ScreenshotResult){
                try{
                    val hw=result.hardwareBuffer
                    val full=Bitmap.wrapHardwareBuffer(hw,result.colorSpace);hw.close()
                    if(full==null){retryCondition(step);return}
                    val screen=full.copy(Bitmap.Config.ARGB_8888,false);full.recycle()
                    executor.execute{
                        var crop:Bitmap?=null;var target:Bitmap?=null
                        try{
                            target=android.graphics.BitmapFactory.decodeFile(Settings.stepTargetPath(this@NextyAccessibilityService,step.id))
                            if(target==null){retryCondition(step);return@execute}
                            val region=Settings.getRegion(this@NextyAccessibilityService)
                            val left=(region?.left?:0f).toInt().coerceIn(0,screen.width-1)
                            val top=(region?.top?:0f).toInt().coerceIn(0,screen.height-1)
                            val right=(region?.right?:screen.width.toFloat()).toInt().coerceIn(left+1,screen.width)
                            val bottom=(region?.bottom?:screen.height.toFloat()).toInt().coerceIn(top+1,screen.height)
                            crop=Bitmap.createBitmap(screen,left,top,right-left,bottom-top)
                            val match=ImageMatcher.find(crop!!,target!!,step.conditionThreshold)
                            if(match.found){
                                busy=false
                                main.post{if(running){currentStep++;executeCurrentStep()}}
                            }else retryCondition(step)
                        }catch(_:Throwable){retryCondition(step)}
                        finally{crop?.recycle();target?.recycle();screen.recycle()}
                    }
                }catch(_:Throwable){retryCondition(step)}
            }
            override fun onFailure(errorCode:Int){retryCondition(step)}
        })
    }
    private fun retryCondition(step:MacroStep){
        busy=false
        if(running)main.postDelayed({waitForCondition(step)},step.conditionInterval.coerceIn(100L,3000L))
    }
    private fun performClick(p:PointF,done:()->Unit){
        val path=Path().apply{moveTo(p.x,p.y)}
        val duration=if(Settings.clickMode(this)==2)650L else 70L
        val g=GestureDescription.Builder().addStroke(GestureDescription.StrokeDescription(path,0,duration)).build()
        dispatchGesture(g,object:GestureResultCallback(){
            override fun onCompleted(gd:GestureDescription?){main.postDelayed(done,Settings.cooldown(this@NextyAccessibilityService).coerceAtLeast(0L))}
            override fun onCancelled(gd:GestureDescription?){main.postDelayed(done,100L)}
        },null)
    }
    private fun toast(s:String)=Toast.makeText(this,s,Toast.LENGTH_SHORT).show()
    private fun removeOverlay(){main.post{stopMacro();val wm=getSystemService(WINDOW_SERVICE) as WindowManager;panel?.let{try{wm.removeView(it)}catch(_:Throwable){}};panel=null;panelStatus=null}}
}
