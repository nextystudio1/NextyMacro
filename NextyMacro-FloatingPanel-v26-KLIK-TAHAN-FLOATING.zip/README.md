# Nexty Macro v21

Strict image condition gate, slower repeat clicks, and real long-press gesture.
