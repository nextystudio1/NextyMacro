package com.nextystudio.nextyimageclick

import android.graphics.Bitmap
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min

data class MatchResult(val found: Boolean, val x: Float = 0f, val y: Float = 0f, val score: Int = 0)

object ImageMatcher {
    // Robust template matching: compare sampled grayscale pixels. The target may be
    // smaller than the search region, so every possible placement is tested.
    fun find(screen: Bitmap, target: Bitmap, threshold: Int): MatchResult {
        if (screen.width < 1 || screen.height < 1 || target.width < 4 || target.height < 4) return MatchResult(false)
        val t = if (target.width > screen.width || target.height > screen.height) {
            val f = min(screen.width.toFloat()/target.width, screen.height.toFloat()/target.height)
            Bitmap.createScaledBitmap(target, max(4,(target.width*f).toInt()), max(4,(target.height*f).toInt()), true)
        } else target
        val tw=t.width; val th=t.height
        val tp=IntArray(tw*th); t.getPixels(tp,0,tw,0,0,tw,th)
        val tg=IntArray(tp.size)
        for(i in tp.indices){ val c=tp[i]; tg[i]=((c ushr 16 and 255)*30+(c ushr 8 and 255)*59+(c and 255)*11)/100 }
        val sp=IntArray(screen.width*screen.height); screen.getPixels(sp,0,screen.width,0,0,screen.width,screen.height)
        var best=Double.POSITIVE_INFINITY; var bx=0; var by=0
        val step = if (tw*th > 250000) 2 else 1
        val posStep = if (screen.width*screen.height > 4000000) 2 else 1
        for(y in 0..(screen.height-th) step posStep){
            for(x in 0..(screen.width-tw) step posStep){
                var diff=0L; var n=0; var i=0
                while(i<tg.size){
                    val ry=i/tw; val rx=i-ry*tw; val c=sp[(y+ry)*screen.width+x+rx]
                    val g=((c ushr 16 and 255)*30+(c ushr 8 and 255)*59+(c and 255)*11)/100
                    diff += abs(g-tg[i]); n++; i+=step
                }
                val e=diff.toDouble()/(n.coerceAtLeast(1)*255.0)*100.0
                if(e<best){best=e;bx=x;by=y}
            }
        }
        if(t!==target)t.recycle()
        val score=(100-best).coerceIn(0.0,100.0).toInt()
        return MatchResult(score>=threshold,bx+tw/2f,by+th/2f,score)
    }
}
