package com.nexty.macro

import android.graphics.Color
import android.graphics.PixelFormat
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import kotlin.math.abs

class RecorderOverlay(
    private val service: NextyAccessibilityService,
    private val onAction: (MacroAction) -> Unit,
    private val onFinish: () -> Unit
) {
    private val wm = service.getSystemService(WindowManager::class.java)
    private var panel: View? = null
    private var touchLayer: View? = null
    private var downX = 0f
    private var downY = 0f
    private var downTime = 0L

    fun show() {
        if (panel != null) return

        val controls = LinearLayout(service).apply {
            orientation = LinearLayout.HORIZONTAL
            setPadding(8, 8, 8, 8)
            setBackgroundColor(0xDD202124.toInt())
        }

        controls.addView(TextView(service).apply {
            text = "  ● REC  "
            setTextColor(Color.WHITE)
            textSize = 16f
        })

        controls.addView(Button(service).apply {
            text = "STOP"
            setOnClickListener { finish() }
        })

        val cp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        )
        cp.gravity = Gravity.TOP or Gravity.CENTER_HORIZONTAL
        cp.y = 80
        wm.addView(controls, cp)
        panel = controls

        val layer = View(service)
        layer.setBackgroundColor(Color.TRANSPARENT)
        layer.setOnTouchListener { _, e ->
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    downX = e.rawX
                    downY = e.rawY
                    downTime = System.currentTimeMillis()
                    true
                }
                MotionEvent.ACTION_UP -> {
                    val x2 = e.rawX
                    val y2 = e.rawY
                    val duration = (System.currentTimeMillis() - downTime).coerceAtLeast(50)
                    if (abs(x2 - downX) > 25 || abs(y2 - downY) > 25) {
                        onAction(MacroAction(
                            ActionType.SWIPE,
                            downX, downY, x2, y2,
                            duration = duration,
                            delayAfter = 300
                        ))
                    } else {
                        onAction(MacroAction(
                            ActionType.TAP,
                            downX, downY,
                            delayAfter = 300
                        ))
                    }
                    true
                }
            }
            true
        }

        val lp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        )
        wm.addView(layer, lp)
        touchLayer = layer
    }

    private fun finish() {
        touchLayer?.let { runCatching { wm.removeView(it) } }
        panel?.let { runCatching { wm.removeView(it) } }
        touchLayer = null
        panel = null
        onFinish()
    }
}
