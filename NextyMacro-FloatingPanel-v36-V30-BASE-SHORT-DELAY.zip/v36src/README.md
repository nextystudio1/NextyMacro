NextyMacro v36 – V30 BASE + SHORT DELAY

Base source is v30. Only Delay behavior is changed:
- New Delay default: 1000 ms (1 second).
- Delay input is limited to 0–2000 ms.
- Macro execution also caps Delay at 2000 ms, so old saved delays cannot make a step wait longer than 2 seconds.
- Accessibility configuration, lifecycle, panel, click/hold, image condition, loop-block, and floating panel code are otherwise unchanged from v30.
