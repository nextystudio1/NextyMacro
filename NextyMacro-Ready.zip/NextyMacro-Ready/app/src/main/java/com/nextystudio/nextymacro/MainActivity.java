package com.nextystudio.nextymacro;

import android.app.*;import android.os.*;import android.provider.Settings;import android.content.*;import android.graphics.Color;import android.view.*;import android.widget.*;import java.util.*;

public class MainActivity extends Activity {
    LinearLayout list; TextView status; Handler handler=new Handler(); boolean running=false; final List<Step> steps=new ArrayList<>();
    static class Step{String type;float a,b,c,d;long duration,delay;Step(String t,float a,float b,float c,float d,long du,long de){type=t;this.a=a;this.b=b;this.c=c;this.d=d;duration=du;delay=de;}}
    TextView tv(String s){TextView t=new TextView(this);t.setText(s);t.setTextSize(16);t.setPadding(12,12,12,12);return t;}
    @Override public void onCreate(Bundle b){super.onCreate(b);ui();}
    void ui(){ScrollView sc=new ScrollView(this);LinearLayout r=new LinearLayout(this);r.setOrientation(LinearLayout.VERTICAL);r.setPadding(18,18,18,18);sc.addView(r);
        TextView title=tv("NEXTY MACRO");title.setTextSize(28);r.addView(title);status=tv("Status: cek Accessibility");r.addView(status);
        Button a=new Button(this);a.setText("Aktifkan Accessibility");a.setOnClickListener(v->startActivity(new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)));r.addView(a);
        Button tap=new Button(this);tap.setText("+ TAP");tap.setOnClickListener(v->tapDialog());r.addView(tap);
        Button swipe=new Button(this);swipe.setText("+ SWIPE");swipe.setOnClickListener(v->swipeDialog());r.addView(swipe);
        Button delay=new Button(this);delay.setText("+ DELAY");delay.setOnClickListener(v->delayDialog());r.addView(delay);
        Button back=new Button(this);back.setText("+ BACK");back.setOnClickListener(v->{steps.add(new Step("BACK",0,0,0,0,0,300));refresh();});r.addView(back);
        Button home=new Button(this);home.setText("+ HOME");home.setOnClickListener(v->{steps.add(new Step("HOME",0,0,0,0,0,300));refresh();});r.addView(home);
        Button clear=new Button(this);clear.setText("Hapus Semua Langkah");clear.setOnClickListener(v->{steps.clear();refresh();});r.addView(clear);
        list=new LinearLayout(this);list.setOrientation(LinearLayout.VERTICAL);r.addView(list);
        Button run=new Button(this);run.setText("▶ JALANKAN 1x");run.setOnClickListener(v->runMacro(1));r.addView(run);
        Button rep=new Button(this);rep.setText("▶ JALANKAN 10x");rep.setOnClickListener(v->runMacro(10));r.addView(rep);
        Button stop=new Button(this);stop.setText("■ STOP");stop.setOnClickListener(v->running=false);r.addView(stop);setContentView(sc);refresh();}
    void refresh(){if(list==null)return;list.removeAllViews();int i=1;for(Step s:steps){String x=i+++". "+s.type;if(s.type.equals("TAP"))x+=" ("+(int)s.a+","+(int)s.b+")";if(s.type.equals("SWIPE"))x+=" ("+(int)s.a+","+(int)s.b+") → ("+(int)s.c+","+(int)s.d+")";if(s.type.equals("DELAY"))x+=" "+s.delay+"ms";list.addView(tv(x));}if(status!=null)status.setText("Status: "+(NextyAccessibilityService.instance!=null?"Accessibility AKTIF":"Accessibility belum aktif"));}
    EditText field(LinearLayout l,String h){EditText e=new EditText(this);e.setHint(h);e.setInputType(2);l.addView(e);return e;}float num(EditText e,float d){try{return Float.parseFloat(e.getText().toString());}catch(Exception x){return d;}}
    void tapDialog(){LinearLayout l=new LinearLayout(this);l.setOrientation(LinearLayout.VERTICAL);EditText x=field(l,"X");EditText y=field(l,"Y");EditText du=field(l,"Durasi ms (80)");new AlertDialog.Builder(this).setTitle("Tambah TAP").setView(l).setPositiveButton("Tambah",(d,w)->{steps.add(new Step("TAP",num(x,0),num(y,0),0,0,(long)num(du,80),300));refresh();}).setNegativeButton("Batal",null).show();}
    void swipeDialog(){LinearLayout l=new LinearLayout(this);l.setOrientation(LinearLayout.VERTICAL);EditText x1=field(l,"X1"),y1=field(l,"Y1"),x2=field(l,"X2"),y2=field(l,"Y2"),du=field(l,"Durasi ms (500)");new AlertDialog.Builder(this).setTitle("Tambah SWIPE").setView(l).setPositiveButton("Tambah",(d,w)->{steps.add(new Step("SWIPE",num(x1,0),num(y1,0),num(x2,0),num(y2,0),(long)num(du,500),300));refresh();}).setNegativeButton("Batal",null).show();}
    void delayDialog(){EditText e=new EditText(this);e.setHint("Milidetik");e.setInputType(2);new AlertDialog.Builder(this).setTitle("Tambah DELAY").setView(e).setPositiveButton("Tambah",(d,w)->{steps.add(new Step("DELAY",0,0,0,0,0,(long)num(e,1000)));refresh();}).setNegativeButton("Batal",null).show();}
    void runMacro(int repeat){if(running||steps.isEmpty())return;if(NextyAccessibilityService.instance==null){Toast.makeText(this,"Aktifkan Accessibility dulu",Toast.LENGTH_LONG).show();return;}running=true;pass(0,repeat);}
    void pass(int n,int total){if(!running||n>=total){running=false;return;}step(0,()->pass(n+1,total));}
    void step(int i,Runnable done){if(!running)return;if(i>=steps.size()){done.run();return;}Step s=steps.get(i);if(s.type.equals("TAP"))NextyAccessibilityService.instance.tap(s.a,s.b,s.duration);else if(s.type.equals("SWIPE"))NextyAccessibilityService.instance.swipe(s.a,s.b,s.c,s.d,s.duration);else if(s.type.equals("BACK"))NextyAccessibilityService.instance.backKey();else if(s.type.equals("HOME"))NextyAccessibilityService.instance.homeKey();long wait=s.type.equals("DELAY")?s.delay:s.delay;handler.postDelayed(()->step(i+1,done),Math.max(30,wait));}
}
