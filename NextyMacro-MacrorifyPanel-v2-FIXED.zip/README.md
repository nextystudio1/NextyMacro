# Nexty Macro - Macrorify Panel v3

Konsep:
- Panel utama menyimpan urutan tindakan.
- Tindakan Klik tidak memakai input X/Y.
- Saat membuat/mengedit Klik, Accessibility overlay menampilkan bulatan `●`.
- Bulatan digeser langsung di atas game/aplikasi target, lalu SIMPAN TITIK.
- Kondisi Gambar juga dibuat langsung dari layar game: Nexty mengambil screenshot, user drag area, dan hasil potongan disimpan sebagai template.
- Setiap tindakan dapat memiliki kondisi gambar sendiri.
- Jika kondisi terpenuhi, koordinat titik tindakan dijalankan.
- Setelah tindakan terakhir selesai, macro kembali ke tindakan #1 sesuai mode loop.
- Tidak mengubah aplikasi/game target; panel/overlay hanya untuk konfigurasi dan eksekusi.

Pemasangan:
Upload isi project atau ZIP sesuai workflow repo yang sudah dipakai.
Jika workflow lama melakukan `unzip NextyMacro-MacrorifyPanel-v2-FIXED.zip -d project`, gunakan nama ZIP ini persis:
`NextyMacro-MacrorifyPanel-v2-FIXED.zip`
