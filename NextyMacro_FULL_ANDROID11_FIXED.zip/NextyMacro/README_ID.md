# Nexty Macro 1.0

Target perangkat: Android 11 / OPPO A92 (CPH2059).

Fitur awal:
- Tindakan berupa koordinat klik.
- Kondisi terpisah berupa template gambar.
- Tindakan dapat dikaitkan dengan kondisi.
- Urutan tindakan berulang dari awal.
- Delay default 0 ms.
- Pemilihan koordinat melalui overlay.
- Screenshot dari AccessibilityService untuk pemeriksaan gambar.

Cara build paling mudah: upload folder/ZIP ini ke GitHub lalu gunakan Android build workflow. APK hasil build dipasang di OPPO A92.

Catatan: pencocokan gambar pada versi ini adalah pencocokan kasar berbasis sampel piksel, sehingga paling cocok untuk gambar UI yang stabil. Ambang kondisi default 88%.
