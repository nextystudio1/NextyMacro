package com.nexty.macro

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

class MacroStore(context: Context) {
    private val prefs = context.getSharedPreferences("nexty_macros", Context.MODE_PRIVATE)

    fun load(): MutableList<Macro> {
        val result = mutableListOf<Macro>()
        val arr = JSONArray(prefs.getString("data", "[]"))
        for (i in 0 until arr.length()) {
            val o = arr.getJSONObject(i)
            val m = Macro(
                o.getLong("id"),
                o.optString("name", "Macro"),
                o.optInt("repeat", 1)
            )
            val actions = o.optJSONArray("actions") ?: JSONArray()
            for (j in 0 until actions.length()) {
                val a = actions.getJSONObject(j)
                m.actions += MacroAction(
                    type = ActionType.valueOf(a.optString("type", "TAP")),
                    x1 = a.optDouble("x1", 0.0).toFloat(),
                    y1 = a.optDouble("y1", 0.0).toFloat(),
                    x2 = a.optDouble("x2", 0.0).toFloat(),
                    y2 = a.optDouble("y2", 0.0).toFloat(),
                    duration = a.optLong("duration", 300),
                    delayAfter = a.optLong("delayAfter", 300),
                    text = a.optString("text", "")
                )
            }
            result += m
        }
        return result
    }

    fun save(macros: List<Macro>) {
        val arr = JSONArray()
        macros.forEach { m ->
            val o = JSONObject()
            o.put("id", m.id)
            o.put("name", m.name)
            o.put("repeat", m.repeat)
            val actions = JSONArray()
            m.actions.forEach { a ->
                actions.put(JSONObject()
                    .put("type", a.type.name)
                    .put("x1", a.x1)
                    .put("y1", a.y1)
                    .put("x2", a.x2)
                    .put("y2", a.y2)
                    .put("duration", a.duration)
                    .put("delayAfter", a.delayAfter)
                    .put("text", a.text))
            }
            o.put("actions", actions)
            arr.put(o)
        }
        prefs.edit().putString("data", arr.toString()).apply()
    }
}
