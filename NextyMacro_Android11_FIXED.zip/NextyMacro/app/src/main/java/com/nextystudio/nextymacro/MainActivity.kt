package com.nextystudio.nextymacro

import android.app.*
import android.content.*
import android.graphics.Color
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.view.*
import android.widget.*
import java.io.File
import java.io.FileOutputStream

class MainActivity : Activity() {
    private lateinit var list: LinearLayout
    private var actions = mutableListOf<MacroAction>()
    private var conditions = mutableListOf<Condition>()
    private var pendingImageName = "Kondisi"

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        requestedOrientation = android.content.pm.ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE
        actions = Store.loadActions(this)
        conditions = Store.loadConditions(this)

        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(24,16,24,16); setBackgroundColor(Color.WHITE) }
        val title = TextView(this).apply { text="NEXTY MACRO"; textSize=24f; setTextColor(Color.BLACK); setTypeface(null, android.graphics.Typeface.BOLD) }
        root.addView(title, LinearLayout.LayoutParams(-1, 60))
        val bar = LinearLayout(this).apply { orientation=LinearLayout.HORIZONTAL }
        bar.addView(button("▶ MULAI") { startMacro() }, weightParams())
        bar.addView(button("■ STOP") { NextyAccessibilityService.stopMacro() }, weightParams())
        bar.addView(button("+ TINDAKAN") { addActionDialog() }, weightParams())
        bar.addView(button("+ KONDISI") { addConditionDialog() }, weightParams())
        bar.addView(button("♿ AKSESIBILITAS") { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }, weightParams())
        root.addView(bar)
        val info = TextView(this).apply { text="Tindakan = koordinat klik. Kondisi = syarat sebelum tindakan dijalankan. Urutan akan mengulang dari awal."; textSize=14f; setPadding(0,12,0,8) }
        root.addView(info)
        list = LinearLayout(this).apply { orientation=LinearLayout.VERTICAL }
        val scroll = ScrollView(this); scroll.addView(list); root.addView(scroll, LinearLayout.LayoutParams(-1,0,1f))
        setContentView(root)
        refresh()
    }

    private fun weightParams() = LinearLayout.LayoutParams(0, 56, 1f).apply { setMargins(4,0,4,0) }
    private fun button(t:String, click:()->Unit)=Button(this).apply { text=t; setOnClickListener{click()} }

    private fun refresh() {
        list.removeAllViews()
        actions.forEachIndexed { i,a ->
            val c = conditions.firstOrNull { it.id==a.conditionId }
            val row=LinearLayout(this).apply { orientation=LinearLayout.HORIZONTAL; setPadding(0,6,0,6) }
            val txt=TextView(this).apply { text="${i+1}. ${a.name}   (${a.x}, ${a.y})" + if(c!=null) "   [Kondisi: ${c.name}]" else "   [Tanpa kondisi]"; textSize=16f }
            row.addView(txt, LinearLayout.LayoutParams(0,60,1f))
            row.addView(button("SET") { pickCoordinate(i) }, LinearLayout.LayoutParams(90,60))
            row.addView(button("HAPUS") { actions.removeAt(i); Store.saveActions(this); refresh() }, LinearLayout.LayoutParams(100,60))
            list.addView(row)
        }
        if (actions.isEmpty()) list.addView(TextView(this).apply { text="Belum ada tindakan."; textSize=18f; setPadding(8,30,8,30) })
    }

    private fun addActionDialog() {
        if (!isServiceEnabled()) { toast("Aktifkan Aksesibilitas Nexty Macro dulu."); startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)); return }
        val input=EditText(this); input.hint="Nama tindakan"
        AlertDialog.Builder(this).setTitle("Tambah Tindakan").setView(input)
            .setMessage("Setelah dibuat, tekan SET untuk memilih titik koordinat.")
            .setPositiveButton("BUAT") { _,_ ->
                val id=System.currentTimeMillis()
                actions.add(MacroAction(id, input.text.toString().ifBlank{"Tindakan ${actions.size+1}"}, 0,0, null,0))
                Store.saveActions(this); refresh()
            }.setNegativeButton("BATAL",null).show()
    }

    private fun pickCoordinate(index:Int) {
        NextyAccessibilityService.setCoordinateCallback { x,y ->
            actions[index]=actions[index].copy(x=x,y=y)
            Store.saveActions(this); runOnUiThread { refresh(); toast("Koordinat disimpan: $x,$y") }
        }
        NextyAccessibilityService.beginCoordinatePick()
        toast("Sentuh titik target di layar.")
    }

    private fun addConditionDialog() {
        val input=EditText(this); input.hint="Nama kondisi"
        AlertDialog.Builder(this).setTitle("Tambah Kondisi Gambar").setView(input)
            .setMessage("Pilih gambar template dari galeri. Template akan dipakai sebagai syarat.")
            .setPositiveButton("PILIH GAMBAR") { _,_ ->
                pendingImageName=input.text.toString().ifBlank{"Kondisi ${conditions.size+1}"}
                startActivityForResult(Intent(Intent.ACTION_OPEN_DOCUMENT).apply { type="image/*"; addCategory(Intent.CATEGORY_OPENABLE) }, 101)
            }.setNegativeButton("BATAL",null).show()
    }

    override fun onActivityResult(requestCode:Int,resultCode:Int,data:Intent?) {
        super.onActivityResult(requestCode,resultCode,data)
        if(requestCode==101 && resultCode==RESULT_OK && data?.data!=null) {
            val uri=data.data!!
            val file=File(filesDir,"condition_${System.currentTimeMillis()}.png")
            contentResolver.openInputStream(uri)?.use { input -> FileOutputStream(file).use { out -> input.copyTo(out) } }
            conditions.add(Condition(System.currentTimeMillis(),pendingImageName,file.absolutePath,88))
            Store.saveConditions(this,conditions)
            toast("Kondisi gambar tersimpan.")
            chooseConditionForAction()
        }
    }

    private fun chooseConditionForAction() {
        if(actions.isEmpty()) return
        val names=conditions.map{it.name}.toTypedArray()
        AlertDialog.Builder(this).setTitle("Pasangkan kondisi ke tindakan")
            .setItems(names) { _,which ->
                val aIndex=actions.lastIndex
                actions[aIndex]=actions[aIndex].copy(conditionId=conditions[which].id)
                Store.saveActions(this); refresh()
            }.setNegativeButton("BATAL",null).show()
    }

    private fun startMacro() {
        if(!isServiceEnabled()){ toast("Aktifkan Aksesibilitas dulu."); return }
        NextyAccessibilityService.startMacro(actions,conditions)
        toast("Macro dimulai.")
    }

    private fun isServiceEnabled():Boolean =
        android.provider.Settings.Secure.getString(contentResolver, android.provider.Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES)?.contains(packageName)==true

    private fun toast(s:String){ Toast.makeText(this,s,Toast.LENGTH_SHORT).show() }
}
