package com.nexty.macro

enum class ActionType {
    TAP, SWIPE, DELAY, BACK, HOME, RECENTS, TEXT
}

data class MacroAction(
    val type: ActionType,
    val x1: Float = 0f,
    val y1: Float = 0f,
    val x2: Float = 0f,
    val y2: Float = 0f,
    val duration: Long = 300L,
    val delayAfter: Long = 300L,
    val text: String = ""
)

data class Macro(
    val id: Long,
    var name: String,
    var repeat: Int = 1,
    val actions: MutableList<MacroAction> = mutableListOf()
)
