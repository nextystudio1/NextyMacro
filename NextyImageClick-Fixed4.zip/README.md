# Nexty Image Click - Fixed4

Versi lanjutan Nexty Image Click untuk Android 11+.

Fitur utama:
- Pilih gambar target
- Match Score 70-100%
- Scan rate 100-3000 ms
- Area deteksi yang bisa dipilih dengan drag
- Deteksi gambar dan klik otomatis di tengah gambar yang ditemukan
- Tap / Double Tap / Long Press
- Delay dan cooldown
- Offset X/Y tersedia melalui Settings API untuk pengembangan berikutnya
- Floating panel Accessibility yang bisa dipindah

Build APK memakai GitHub Actions workflow `Build Nexty Image Click`.
