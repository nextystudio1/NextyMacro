package com.nextystudio.nextyimageclick

import android.content.Context
import android.graphics.PointF

object Settings {
    private const val PREF = "nexty"
    private const val TARGET = "target.png"
    private const val X = "click_x"
    private const val Y = "click_y"
    private const val THRESH = "threshold"
    private const val INTERVAL = "interval"

    fun saveTarget(context: Context, bytes: ByteArray) {
        context.openFileOutput(TARGET, Context.MODE_PRIVATE).use { it.write(bytes) }
    }

    fun targetExists(context: Context) = context.getFileStreamPath(TARGET).exists()

    fun targetPath(context: Context) = context.getFileStreamPath(TARGET).absolutePath

    fun savePoint(context: Context, p: PointF) {
        context.getSharedPreferences(PREF, 0).edit()
            .putFloat(X, p.x).putFloat(Y, p.y).apply()
    }

    fun getPoint(context: Context): PointF? {
        val p = context.getSharedPreferences(PREF, 0)
        if (!p.contains(X)) return null
        return PointF(p.getFloat(X, 0f), p.getFloat(Y, 0f))
    }

    fun saveThreshold(context: Context, v: Int) =
        context.getSharedPreferences(PREF, 0).edit().putInt(THRESH, v).apply()

    fun threshold(context: Context) =
        context.getSharedPreferences(PREF, 0).getInt(THRESH, 82)

    fun saveInterval(context: Context, v: Long) =
        context.getSharedPreferences(PREF, 0).edit().putLong(INTERVAL, v).apply()

    fun interval(context: Context) =
        context.getSharedPreferences(PREF, 0).getLong(INTERVAL, 500L)
}
