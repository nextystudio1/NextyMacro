package com.nextystudio.nextyimageclick

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.graphics.*
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.view.*
import android.widget.*
import java.util.concurrent.Executors
import kotlin.math.roundToInt

class NextyAccessibilityService : AccessibilityService() {
    companion object { private var instance: NextyAccessibilityService? = null; fun get() = instance }

    private val main = Handler(Looper.getMainLooper())
    private val executor = Executors.newSingleThreadExecutor()
    private var panel: LinearLayout? = null
    private var bubble: TextView? = null
    private var bubbleParams: WindowManager.LayoutParams? = null
    private var panelStatus: TextView? = null
    private var panelSteps: LinearLayout? = null
    private var running = false
    private var busy = false
    private var currentStep = 0
    private var completedLoops = 0

    override fun onServiceConnected() { super.onServiceConnected(); instance = this }
    override fun onDestroy() { instance = null; executor.shutdownNow(); removePanel(); super.onDestroy() }
    override fun onAccessibilityEvent(event: android.view.accessibility.AccessibilityEvent?) {}
    override fun onInterrupt() {}

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).roundToInt()

    fun showPanel() {
        main.post {
            if (bubble == null) createBubble()
            togglePanel(true)
        }
    }

    private fun createBubble() {
        val wm = getSystemService(WINDOW_SERVICE) as WindowManager
        val b = TextView(this).apply {
            text = "N"
            textSize = 20f
            gravity = Gravity.CENTER
            setTextColor(Color.WHITE)
            background = android.graphics.drawable.GradientDrawable().apply {
                shape = android.graphics.drawable.GradientDrawable.OVAL
                setColor(0xFF6C5CE7.toInt())
                setStroke(dp(2), 0x55FFFFFF)
            }
            elevation = dp(8).toFloat()
        }
        val lp = WindowManager.LayoutParams(
            dp(54), dp(54), WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.TOP or Gravity.END; x = dp(12); y = dp(110) }
        bubbleParams = lp
        var downX = 0f; var downY = 0f; var startX = 0; var startY = 0; var moved = false
        b.setOnTouchListener { v, e ->
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> { downX = e.rawX; downY = e.rawY; startX = lp.x; startY = lp.y; moved = false; true }
                MotionEvent.ACTION_MOVE -> {
                    val dx = (e.rawX - downX).roundToInt(); val dy = (e.rawY - downY).roundToInt()
                    if (kotlin.math.abs(dx) > dp(4) || kotlin.math.abs(dy) > dp(4)) moved = true
                    lp.x = (startX + dx).coerceAtLeast(0); lp.y = (startY + dy).coerceAtLeast(0)
                    try { wm.updateViewLayout(v, lp) } catch (_: Throwable) {}
                    true
                }
                MotionEvent.ACTION_UP -> { if (!moved) togglePanel(panel == null); true }
                else -> true
            }
        }
        wm.addView(b, lp)
        bubble = b
    }

    private fun togglePanel(show: Boolean) {
        if (show) {
            if (panel != null) return
            val wm = getSystemService(WINDOW_SERVICE) as WindowManager
            val root = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                setPadding(dp(3), dp(2), dp(3), dp(3))
                background = android.graphics.drawable.GradientDrawable().apply {
                    cornerRadius = dp(12).toFloat()
                    setColor(0xF21A1A1F.toInt())
                    setStroke(dp(1), 0x44FFFFFF)
                }
                elevation = dp(12).toFloat()
            }
            val header = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL; setPadding(dp(1), 0, 0, 0) }
            header.addView(TextView(this).apply { text = "NEXTY"; textSize = 12f; setTypeface(typeface, android.graphics.Typeface.BOLD); setTextColor(Color.WHITE) }, LinearLayout.LayoutParams(0, -2, 1f))
            header.addView(panelButton("×") { togglePanel(false) }.apply { minWidth = dp(22); minHeight = dp(22) })
            panelStatus = TextView(this).apply { text = statusText(); textSize = 9f; setTextColor(0xFFB8B8C2.toInt()); setPadding(dp(3), 0, dp(3), dp(2)) }
            panelSteps = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
            val scroll = ScrollView(this).apply { addView(panelSteps) }
            val addRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
            addRow.addView(panelButton("＋ KLIK") { addClick() }, LinearLayout.LayoutParams(0, dp(24), 1f).also { it.setMargins(0,0,dp(3),0) })
            addRow.addView(panelButton("＋ DELAY") { addDelay() }, LinearLayout.LayoutParams(0, dp(24), 1f))
            val loop = panelButton("🔁 ${loopLabel()}") { showLoopDialog() }
            val start = panelButton("▶ START") { startMacro() }
            val stop = panelButton("■ STOP") { stopMacro() }
            root.addView(header)
            root.addView(panelStatus)
            root.addView(scroll, LinearLayout.LayoutParams(-1, dp(118)))
            root.addView(addRow)
            val runRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
            runRow.addView(loop, LinearLayout.LayoutParams(0, dp(24), 1f).also { it.setMargins(0,0,dp(3),0) })
            runRow.addView(start, LinearLayout.LayoutParams(0, dp(24), 1f).also { it.setMargins(0,0,dp(3),0) })
            runRow.addView(stop, LinearLayout.LayoutParams(0, dp(24), 1f))
            root.addView(runRow)
            val lp = WindowManager.LayoutParams(
                dp(155), -2, WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
                PixelFormat.TRANSLUCENT
            ).apply { gravity = Gravity.TOP or Gravity.END; x = dp(10); y = dp(85) }
            header.setOnTouchListener(object : View.OnTouchListener {
                var dx=0f; var dy=0f; var sx=0; var sy=0
                override fun onTouch(v: View, e: MotionEvent): Boolean = when(e.actionMasked) {
                    MotionEvent.ACTION_DOWN -> { dx=e.rawX; dy=e.rawY; sx=lp.x; sy=lp.y; true }
                    MotionEvent.ACTION_MOVE -> { lp.x=sx+(e.rawX-dx).roundToInt(); lp.y=sy+(e.rawY-dy).roundToInt(); try{wm.updateViewLayout(root,lp)}catch(_:Throwable){}; true }
                    else -> true
                }
            })
            wm.addView(root, lp); panel=root; refreshPanel()
        } else removePanelOnly()
    }

    private fun removePanelOnly() {
        val work = {
            val wm = getSystemService(WINDOW_SERVICE) as WindowManager
            panel?.let { try { wm.removeViewImmediate(it) } catch (_: Throwable) {} }
            panel = null
            panelStatus = null
            panelSteps = null
        }
        if (Looper.myLooper() == Looper.getMainLooper()) work() else main.post(work)
    }

    private fun panelButton(textValue: String, action: () -> Unit) = Button(this).apply {
        text = textValue; textSize = 8f; minHeight = 0; minWidth = 0; setPadding(dp(1), 0, dp(1), 0); setOnClickListener { action() }
    }

    private fun statusText(): String {
        val n = MacroStore.getSteps(this).size
        return if (running) "RUN • tindakan ${currentStep + 1}/$n • putaran ${completedLoops + 1}" else "STOP • $n tindakan"
    }

    private fun loopLabel(): String = when (MacroStore.loopMode(this)) {
        0 -> "SEKALI"
        1 -> "${MacroStore.loopCount(this)}x"
        else -> "∞"
    }

    private fun refreshPanel() {
        main.post {
            panelStatus?.text = statusText()
            panelSteps?.removeAllViews()
            val steps = MacroStore.getSteps(this)
            if (steps.isEmpty()) {
                panelSteps?.addView(TextView(this).apply { text = "Belum ada tindakan. Tambahkan dari panel ini."; setTextColor(0xFFBDBDBD.toInt()); setPadding(dp(8), dp(10), dp(8), dp(10)) })
            } else steps.forEachIndexed { index, step -> panelSteps?.addView(stepView(index, step)) }
        }
    }

    private fun stepView(index: Int, step: MacroStep): View {
        val card = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(3), dp(2), dp(3), dp(2))
            setBackgroundColor(0xFF262626.toInt())
        }
        val head = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL }
        head.addView(TextView(this).apply {
            text = "${index + 1}. ${if (step.type == StepType.DELAY) "DELAY" else "KLIK"}"
            textSize = 10f; setTextColor(Color.WHITE)
        }, LinearLayout.LayoutParams(0, -2, 1f))
        head.addView(panelButton("↑") { move(index, -1) })
        head.addView(panelButton("↓") { move(index, 1) })
        head.addView(panelButton("×") { removeStep(index) })
        card.addView(head)

        if (step.type == StepType.CLICK_COORD) {
            card.addView(TextView(this).apply {
                text = if (step.x == 0f && step.y == 0f) "● Titik belum dipasang di game" else "● Titik klik tersimpan di game"
                textSize = 8f; setTextColor(0xFFFFC107.toInt()); setPadding(0, dp(2), 0, dp(2))
            })
            card.addView(panelButton("ATUR TITIK ● DI GAME") { editClick(index) })
        } else {
            card.addView(TextView(this).apply { text = "⏱ ${step.delayMs} ms"; textSize = 9f; setTextColor(0xFFBDBDBD.toInt()) })
            card.addView(panelButton("EDIT DELAY") { editDelay(index) })
        }

        val cond = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(3), dp(2), dp(3), dp(2)); setBackgroundColor(0xFF332B1C.toInt()) }
        cond.addView(TextView(this).apply { text = "KONDISI • GAMBAR MUNCUL"; textSize = 9f; setTextColor(0xFFFFB74D.toInt()) })
        if (step.conditionImage) {
            cond.addView(TextView(this).apply {
                text = "✓ ${if (Settings.stepTargetExists(this@NextyAccessibilityService, step.id)) "gambar tersimpan" else "gambar belum ada"} • match ${step.conditionThreshold}% • scan ${step.conditionInterval}ms"
                textSize = 8f; setTextColor(0xFFE0E0E0.toInt())
            })
            cond.addView(panelButton("EDIT / AMBIL GAMBAR DARI GAME") { editCondition(index) })
        } else {
            cond.addView(TextView(this).apply { text = "Tidak aktif — tindakan dijalankan langsung"; textSize = 8f; setTextColor(0xFFBDBDBD.toInt()) })
            cond.addView(panelButton("＋ TAMBAH KONDISI") { addCondition(index) })
        }
        card.addView(cond)
        return card.apply { layoutParams = LinearLayout.LayoutParams(-1, -2).also { it.setMargins(0, 0, 0, dp(3)) } }
    }

    private fun addClick() {
        val steps = MacroStore.getSteps(this)
        steps.add(MacroStep(StepType.CLICK_COORD, "Klik"))
        MacroStore.saveSteps(this, steps)
        val index = steps.lastIndex
        refreshPanel()
        startCoordinatePicker { p ->
            val s = MacroStore.getSteps(this)
            if (index in s.indices) { s[index] = s[index].copy(x = p.x, y = p.y); MacroStore.saveSteps(this, s); refreshPanel() }
        }
    }

    private fun editClick(index: Int) {
        startCoordinatePicker { p ->
            val s = MacroStore.getSteps(this)
            if (index in s.indices) { s[index] = s[index].copy(x = p.x, y = p.y); MacroStore.saveSteps(this, s); refreshPanel() }
        }
    }

    private fun addDelay() { showDelay(-1) }
    private fun editDelay(index: Int) { showDelay(index) }

    private fun showDelay(index: Int) {
        val input = EditText(this).apply { inputType = android.text.InputType.TYPE_CLASS_NUMBER; setText(if (index >= 0) MacroStore.getSteps(this@NextyAccessibilityService)[index].delayMs.toString() else "500") }
        AlertDialogCompat(this, "Delay (ms)", input) { value ->
            val ms = value.toLongOrNull()?.coerceAtLeast(0L) ?: 500L
            val s = MacroStore.getSteps(this)
            if (index < 0) s.add(MacroStep(StepType.DELAY, "Delay", delayMs = ms))
            else if (index in s.indices) s[index] = s[index].copy(delayMs = ms)
            MacroStore.saveSteps(this, s); refreshPanel()
        }
    }

    private fun addCondition(index: Int) {
        val s = MacroStore.getSteps(this)
        if (index !in s.indices) return
        s[index] = s[index].copy(conditionImage = true, conditionThreshold = 85, conditionInterval = 500)
        MacroStore.saveSteps(this, s); refreshPanel(); captureCondition(index)
    }

    private fun editCondition(index: Int) { captureCondition(index) }

    private fun captureCondition(index: Int) {
        if (Build.VERSION.SDK_INT < 30) { toast("Android 11+ diperlukan."); return }
        takeScreenshot(0, executor, object : TakeScreenshotCallback {
            override fun onSuccess(result: ScreenshotResult) {
                try {
                    val hw = result.hardwareBuffer
                    val raw = Bitmap.wrapHardwareBuffer(hw, result.colorSpace)
                    hw.close()
                    if (raw == null) { toast("Gagal mengambil screenshot."); return }
                    val bmp = raw.copy(Bitmap.Config.ARGB_8888, false); raw.recycle()
                    main.post { showCropOverlay(bmp, index) }
                } catch (_: Throwable) { toast("Gagal mengambil screenshot.") }
            }
            override fun onFailure(errorCode: Int) { toast("Screenshot gagal: $errorCode") }
        })
    }

    private fun showCropOverlay(bitmap: Bitmap, index: Int) {
        val wm = getSystemService(WINDOW_SERVICE) as WindowManager
        val root = FrameLayout(this).apply { setBackgroundColor(Color.BLACK) }
        root.addView(ImageView(this).apply { setImageBitmap(bitmap); scaleType = ImageView.ScaleType.FIT_XY }, FrameLayout.LayoutParams(-1, -1))
        val selector = CropSelector(this).apply { setBitmapSize(bitmap.width, bitmap.height) }
        root.addView(selector, FrameLayout.LayoutParams(-1, -1))
        root.addView(TextView(this).apply { text = "PILIH GAMBAR KONDISI • tarik kotak di layar game"; textSize = 16f; gravity = Gravity.CENTER; setTextColor(Color.WHITE); setBackgroundColor(0xAA000000.toInt()); setPadding(dp(10), dp(8), dp(10), dp(8)) }, FrameLayout.LayoutParams(-1, -2, Gravity.TOP))
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; setBackgroundColor(0xEE111111.toInt()) }
        row.addView(Button(this).apply { text = "BATAL"; setOnClickListener { remove(root); bitmap.recycle() } }, LinearLayout.LayoutParams(0, -2, 1f))
        row.addView(Button(this).apply {
            text = "SIMPAN"
            setOnClickListener {
                val r = selector.selection()
                if (r.width() < 10f || r.height() < 10f) { toast("Area terlalu kecil."); return@setOnClickListener }
                try {
                    val l = r.left.toInt().coerceIn(0, bitmap.width - 1)
                    val t = r.top.toInt().coerceIn(0, bitmap.height - 1)
                    val rr = r.right.toInt().coerceIn(l + 1, bitmap.width)
                    val bb = r.bottom.toInt().coerceIn(t + 1, bitmap.height)
                    val crop = Bitmap.createBitmap(bitmap, l, t, rr - l, bb - t)
                    val out = java.io.ByteArrayOutputStream(); crop.compress(Bitmap.CompressFormat.PNG, 100, out); crop.recycle()
                    val s = MacroStore.getSteps(this@NextyAccessibilityService)
                    if (index in s.indices) {
                        Settings.saveStepTarget(this@NextyAccessibilityService, s[index].id, out.toByteArray())
                        s[index] = s[index].copy(conditionImage = true, regionL = l.toFloat(), regionT = t.toFloat(), regionR = rr.toFloat(), regionB = bb.toFloat())
                        MacroStore.saveSteps(this@NextyAccessibilityService, s)
                    }
                    remove(root); bitmap.recycle(); refreshPanel()
                } catch (_: Throwable) { toast("Gagal menyimpan gambar.") }
            }
        }, LinearLayout.LayoutParams(0, -2, 1f))
        root.addView(row, FrameLayout.LayoutParams(-1, -2, Gravity.BOTTOM))
        wm.addView(root, fullOverlayParams())
    }

    private fun showLoopDialog() {
        val options = arrayOf("Sekali", "Ulangi N kali", "Tanpa batas")
        val current = MacroStore.loopMode(this)
        android.app.AlertDialog.Builder(this).setTitle("Loop macro").setSingleChoiceItems(options, current) { d, which ->
            if (which == 1) {
                val input = EditText(this).apply { inputType = android.text.InputType.TYPE_CLASS_NUMBER; setText(MacroStore.loopCount(this@NextyAccessibilityService).toString()) }
                android.app.AlertDialog.Builder(this).setTitle("Jumlah putaran").setView(input).setPositiveButton("Simpan") { _, _ -> MacroStore.saveLoop(this, 1, input.text.toString().toIntOrNull() ?: 1); d.dismiss(); refreshPanel() }.setNegativeButton("Batal", null).show()
            } else { MacroStore.saveLoop(this, which, 1); d.dismiss(); refreshPanel() }
        }.show()
    }

    private fun move(i: Int, delta: Int) { val s = MacroStore.getSteps(this); val j = i + delta; if (i in s.indices && j in s.indices) { val v = s.removeAt(i); s.add(j, v); MacroStore.saveSteps(this, s); refreshPanel() } }
    private fun removeStep(i: Int) { val s = MacroStore.getSteps(this); if (i in s.indices) { s.removeAt(i); MacroStore.saveSteps(this, s); refreshPanel() } }

    // Full-screen overlay used only while placing a click point on the target game.
    fun startCoordinatePicker(onPicked: (PointF) -> Unit) {
        val wm = getSystemService(WINDOW_SERVICE) as WindowManager
        val root = FrameLayout(this).apply { setBackgroundColor(0x22000000) }
        root.addView(TextView(this).apply { text = "GESER BULATAN ● KE POSISI KLIK"; textSize = 18f; gravity = Gravity.CENTER; setTextColor(Color.WHITE); setBackgroundColor(0xAA000000.toInt()); setPadding(dp(12), dp(10), dp(12), dp(10)) }, FrameLayout.LayoutParams(-2, -2, Gravity.TOP or Gravity.CENTER_HORIZONTAL).apply { topMargin = dp(35) })
        val circle = TextView(this).apply { text = "●"; textSize = 64f; gravity = Gravity.CENTER; setTextColor(0xFFFF9F1C.toInt()) }
        val cp = FrameLayout.LayoutParams(dp(96), dp(96)).apply { leftMargin = dp(120); topMargin = dp(220) }
        root.addView(circle, cp)
        val buttons = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        buttons.addView(Button(this).apply { text = "BATAL"; setOnClickListener { remove(root) } }, LinearLayout.LayoutParams(0, -2, 1f))
        buttons.addView(Button(this).apply { text = "SIMPAN TITIK"; setOnClickListener {
            // Convert the marker position to real display/screen coordinates.
            // Do not use leftMargin/topMargin directly because an accessibility
            // overlay can have a window origin different from (0,0).
            val loc = IntArray(2)
            circle.getLocationOnScreen(loc)
            val p = PointF(loc[0] + circle.width / 2f, loc[1] + circle.height / 2f)
            remove(root)
            onPicked(p)
        } }, LinearLayout.LayoutParams(0, -2, 1f))
        root.addView(buttons, FrameLayout.LayoutParams(-1, -2, Gravity.BOTTOM))
        circle.setOnTouchListener(object : View.OnTouchListener {
            var dx = 0f; var dy = 0f
            override fun onTouch(v: View, e: MotionEvent): Boolean = when (e.action) {
                MotionEvent.ACTION_DOWN -> {
                    val lp = circle.layoutParams as FrameLayout.LayoutParams
                    val loc = IntArray(2)
                    root.getLocationOnScreen(loc)
                    dx = e.rawX - (loc[0] + lp.leftMargin)
                    dy = e.rawY - (loc[1] + lp.topMargin)
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    val lp = circle.layoutParams as FrameLayout.LayoutParams
                    val loc = IntArray(2)
                    root.getLocationOnScreen(loc)
                    lp.leftMargin = (e.rawX - loc[0] - dx).roundToInt().coerceIn(0, (root.width - lp.width).coerceAtLeast(0))
                    lp.topMargin = (e.rawY - loc[1] - dy).roundToInt().coerceIn(0, (root.height - lp.height - dp(70)).coerceAtLeast(0))
                    circle.layoutParams = lp
                    true
                }
                else -> true
            }
        })
        wm.addView(root, fullOverlayParams())
    }

    private fun fullOverlayParams() = WindowManager.LayoutParams(-1, -1, WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY, WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE, PixelFormat.TRANSLUCENT)
    private fun remove(v: View) { try { (getSystemService(WINDOW_SERVICE) as WindowManager).removeView(v) } catch (_: Throwable) {} }

    private class CropSelector(c: android.content.Context) : View(c) {
        private val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; strokeWidth = 5f; color = Color.YELLOW }
        private var sx = 0f; private var sy = 0f; private var ex = 0f; private var ey = 0f; private var active = false; private var bw = 1; private var bh = 1
        fun setBitmapSize(w: Int, h: Int) { bw = w; bh = h }
        fun selection(): RectF { val vw = width.toFloat().coerceAtLeast(1f); val vh = height.toFloat().coerceAtLeast(1f); return RectF(minOf(sx, ex) * bw / vw, minOf(sy, ey) * bh / vh, maxOf(sx, ex) * bw / vw, maxOf(sy, ey) * bh / vh) }
        override fun onDraw(canvas: Canvas) { super.onDraw(canvas); if (active) canvas.drawRect(minOf(sx, ex), minOf(sy, ey), maxOf(sx, ex), maxOf(sy, ey), paint) }
        override fun onTouchEvent(e: MotionEvent): Boolean = when (e.action) { MotionEvent.ACTION_DOWN -> { sx = e.x; sy = e.y; ex = e.x; ey = e.y; active = true; invalidate(); true }; MotionEvent.ACTION_MOVE -> { ex = e.x; ey = e.y; invalidate(); true }; MotionEvent.ACTION_UP -> { ex = e.x; ey = e.y; invalidate(); true }; else -> true }
    }

    fun startMacro() {
        if (running) return
        val steps = MacroStore.getSteps(this)
        if (steps.isEmpty()) { toast("Tambahkan tindakan dulu."); return }
        if (Build.VERSION.SDK_INT < 30) { toast("Android 11+ diperlukan."); return }
        val bad = steps.withIndex().firstOrNull { it.value.conditionImage && (!Settings.stepTargetExists(this, it.value.id) || !it.value.hasRegion()) }
        if (bad != null) { toast("Kondisi tindakan #${bad.index + 1} belum lengkap."); return }
        running = true; busy = false; currentStep = 0; completedLoops = 0
        toast("START • ${steps.size} tindakan")
        // Close the editor and temporarily hide the bubble so neither overlay can
        // cover the target point while the macro is clicking the game.
        removePanelOnly()
        bubble?.let { b ->
            try { (getSystemService(WINDOW_SERVICE) as WindowManager).removeView(b) } catch (_: Throwable) {}
            bubble = null
        }
        // Give Android a moment to detach the floating editor before injecting the tap.
        main.postDelayed({ if (running) executeCurrentStep() }, 650L)
    }

    fun stopMacro() {
        running = false
        busy = false
        main.removeCallbacksAndMessages(null)
        if (bubble == null) main.post { try { createBubble() } catch (_: Throwable) {} }
        refreshPanel()
        toast("Macro dihentikan")
    }

    private fun executeCurrentStep() {
        if (!running) return
        val steps = MacroStore.getSteps(this)
        if (steps.isEmpty()) { stopMacro(); return }
        if (currentStep >= steps.size) {
            completedLoops++
            val mode = MacroStore.loopMode(this)
            if (mode == 0 || (mode == 1 && completedLoops >= MacroStore.loopCount(this))) { running = false; refreshPanel(); toast("Selesai $completedLoops putaran"); return }
            currentStep = 0; refreshPanel(); main.post { executeCurrentStep() }; return
        }
        refreshPanel()
        val step = steps[currentStep]
        if (step.conditionImage) { waitForConditionThenAction(step) } else performAction(step)
    }

    // IMPORTANT: condition is a gate for the SAME action. When the image is found,
    // the action at this index is executed; only after the action completes do we advance.
    private fun waitForConditionThenAction(step: MacroStep) {
        if (!running || busy) return
        busy = true
        takeScreenshot(0, executor, object : TakeScreenshotCallback {
            override fun onSuccess(result: ScreenshotResult) {
                try {
                    val hw = result.hardwareBuffer
                    val raw = Bitmap.wrapHardwareBuffer(hw, result.colorSpace)
                    hw.close()
                    if (raw == null) { retryCondition(step); return }
                    val screen = raw.copy(Bitmap.Config.ARGB_8888, false); raw.recycle()
                    executor.execute {
                        var crop: Bitmap? = null; var target: Bitmap? = null
                        try {
                            target = BitmapFactory.decodeFile(Settings.stepTargetPath(this@NextyAccessibilityService, step.id))
                            if (target == null) { retryCondition(step); return@execute }
                            val left = step.regionL.toInt().coerceIn(0, screen.width - 1)
                            val top = step.regionT.toInt().coerceIn(0, screen.height - 1)
                            val right = step.regionR.toInt().coerceIn(left + 1, screen.width)
                            val bottom = step.regionB.toInt().coerceIn(top + 1, screen.height)
                            crop = Bitmap.createBitmap(screen, left, top, right - left, bottom - top)
                            val match = ImageMatcher.find(crop!!, target!!, step.conditionThreshold)
                            if (match.found) { busy = false; main.post { if (running) performAction(step) } } else retryCondition(step)
                        } catch (_: Throwable) { retryCondition(step) }
                        finally { crop?.recycle(); target?.recycle(); screen.recycle() }
                    }
                } catch (_: Throwable) { retryCondition(step) }
            }
            override fun onFailure(errorCode: Int) { retryCondition(step) }
        })
    }

    private fun retryCondition(step: MacroStep) { busy = false; if (running) main.postDelayed({ waitForConditionThenAction(step) }, step.conditionInterval.coerceIn(100L, 3000L)) }

    private fun performAction(step: MacroStep) {
        if (!running) return
        when (step.type) {
            StepType.DELAY -> main.postDelayed({ if (running) { currentStep++; executeCurrentStep() } }, step.delayMs.coerceAtLeast(0L))
            StepType.CLICK_COORD -> {
                if (step.x == 0f && step.y == 0f) { toast("Tindakan #${currentStep + 1} belum punya titik."); stopMacro(); return }
                toast("KLIK ${step.x.toInt()}, ${step.y.toInt()}")
                performClick(PointF(step.x, step.y)) { currentStep++; executeCurrentStep() }
            }
        }
    }

    private fun performClick(p: PointF, done: () -> Unit) {
        if (!running) return

        // Accessibility gestures use absolute display coordinates in pixels.
        // The picker stores getLocationOnScreen(), so use those coordinates
        // directly. A canonical Android tap is a one-point path with a
        // 1 ms stroke; do not turn it into a 1 px swipe.
        val wm = getSystemService(WINDOW_SERVICE) as WindowManager
        val dm = android.util.DisplayMetrics()
        @Suppress("DEPRECATION")
        wm.defaultDisplay.getRealMetrics(dm)

        val x = p.x.coerceIn(0f, (dm.widthPixels - 1).toFloat())
        val y = p.y.coerceIn(0f, (dm.heightPixels - 1).toFloat())

        val path = Path().apply { moveTo(x, y) }
        val gesture = GestureDescription.Builder()
            .addStroke(GestureDescription.StrokeDescription(path, 0L, 1L))
            .build()

        val callback = object : GestureResultCallback() {
            override fun onCompleted(gestureDescription: GestureDescription?) {
                toast("✓ TAP ${x.toInt()},${y.toInt()}")
                main.postDelayed({ if (running) done() }, 100L)
            }

            override fun onCancelled(gestureDescription: GestureDescription?) {
                toast("✕ GESTURE DIBATALKAN")
                if (running) {
                    main.postDelayed({ performClick(p, done) }, 500L)
                }
            }
        }

        val accepted = try {
            dispatchGesture(gesture, callback, main)
        } catch (t: Throwable) {
            toast("✕ GESTURE ERROR: ${t.javaClass.simpleName}")
            false
        }

        if (!accepted && running) {
            toast("✕ ANDROID MENOLAK GESTURE")
            main.postDelayed({ performClick(p, done) }, 500L)
        }
    }

    private fun toast(s: String) = main.post { Toast.makeText(this, s, Toast.LENGTH_SHORT).show() }
    private fun removePanel() { main.post { stopMacro(); val wm = getSystemService(WINDOW_SERVICE) as WindowManager; panel?.let { try { wm.removeView(it) } catch (_: Throwable) {} }; bubble?.let { try { wm.removeView(it) } catch (_: Throwable) {} }; panel = null; bubble = null; panelStatus = null; panelSteps = null } }
}

private fun AlertDialogCompat(service: NextyAccessibilityService, title: String, input: EditText, save: (String) -> Unit) {
    android.app.AlertDialog.Builder(service).setTitle(title).setView(input).setPositiveButton("Simpan") { _, _ -> save(input.text.toString()) }.setNegativeButton("Batal", null).show()
}
