NextyMacro v31 – FAST ACTION TRANSITION
- Removes extra panel refresh work between actions.
- Condition scan default is 50 ms; retry minimum is 20 ms.
- Keeps user-configured Delay, Hold duration, and repeated-click interval.
- Keeps loop-block behavior and floating panel behavior from v30.
