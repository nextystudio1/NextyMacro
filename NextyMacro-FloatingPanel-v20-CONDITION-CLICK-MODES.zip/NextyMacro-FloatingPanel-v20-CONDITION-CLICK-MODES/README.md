Nexty Macro v20. Adds click repeat/hold modes, robust condition matching with expanded search region, condition test button, and preserves action delete.
