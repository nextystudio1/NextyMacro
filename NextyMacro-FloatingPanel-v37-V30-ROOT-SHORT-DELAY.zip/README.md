NextyMacro v37 – V30 BASE + SHORT DELAY

This ZIP preserves the exact v30 project layout at the ZIP root.
Only Delay behavior is changed:
- Default Delay: 1000 ms (1 second).
- Delay input and execution are capped at 2000 ms (2 seconds).
- Accessibility, lifecycle, panel, click/hold, image condition, loop, and floating-panel code are otherwise unchanged from v30.

GitHub Actions can build this project directly with: gradle :app:assembleDebug
