package com.nextystudio.nextyimageclick

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.util.UUID

enum class StepType { CLICK_COORD, DELAY }

data class MacroStep(
    val type: StepType,
    val title: String,
    val delayMs: Long = 0L,
    val x: Float = 0f,
    val y: Float = 0f,
    val id: String = UUID.randomUUID().toString(),
    val conditionImage: Boolean = false,
    val conditionThreshold: Int = 85,
    val conditionInterval: Long = 500L,
    val regionL: Float = 0f,
    val regionT: Float = 0f,
    val regionR: Float = 0f,
    val regionB: Float = 0f
) {
    fun hasRegion() = regionR > regionL && regionB > regionT
}

object MacroStore {
    private const val PREF = "nexty_macro"
    private const val STEPS = "steps"
    private const val LOOP_MODE = "loop_mode"
    private const val LOOP_COUNT = "loop_count"
    private fun prefs(c: Context) = c.getSharedPreferences(PREF, Context.MODE_PRIVATE)

    fun getSteps(c: Context): MutableList<MacroStep> {
        val raw = prefs(c).getString(STEPS, null) ?: return mutableListOf()
        return try {
            val a = JSONArray(raw)
            MutableList(a.length()) { i ->
                val o = a.getJSONObject(i)
                MacroStep(
                    type = StepType.valueOf(o.optString("type", StepType.CLICK_COORD.name)),
                    title = o.optString("title", "Tindakan"),
                    delayMs = o.optLong("delay", 0L),
                    x = o.optDouble("x", 0.0).toFloat(),
                    y = o.optDouble("y", 0.0).toFloat(),
                    id = o.optString("id", UUID.randomUUID().toString()),
                    conditionImage = o.optBoolean("conditionImage", false),
                    conditionThreshold = o.optInt("conditionThreshold", 85).coerceIn(50, 100),
                    conditionInterval = o.optLong("conditionInterval", 500L).coerceIn(100L, 3000L),
                    regionL = o.optDouble("rl", 0.0).toFloat(),
                    regionT = o.optDouble("rt", 0.0).toFloat(),
                    regionR = o.optDouble("rr", 0.0).toFloat(),
                    regionB = o.optDouble("rb", 0.0).toFloat()
                )
            }
        } catch (_: Throwable) { mutableListOf() }
    }

    fun saveSteps(c: Context, steps: List<MacroStep>) {
        val a = JSONArray()
        steps.forEach { s ->
            a.put(JSONObject().apply {
                put("type", s.type.name); put("title", s.title); put("delay", s.delayMs)
                put("x", s.x); put("y", s.y); put("id", s.id)
                put("conditionImage", s.conditionImage)
                put("conditionThreshold", s.conditionThreshold)
                put("conditionInterval", s.conditionInterval)
                put("rl", s.regionL); put("rt", s.regionT); put("rr", s.regionR); put("rb", s.regionB)
            })
        }
        prefs(c).edit().putString(STEPS, a.toString()).apply()
    }
    fun loopMode(c: Context) = prefs(c).getInt(LOOP_MODE, 2)
    fun loopCount(c: Context) = prefs(c).getInt(LOOP_COUNT, 10).coerceAtLeast(1)
    fun saveLoop(c: Context, mode: Int, count: Int) = prefs(c).edit()
        .putInt(LOOP_MODE, mode.coerceIn(0, 2)).putInt(LOOP_COUNT, count.coerceAtLeast(1)).apply()
}
