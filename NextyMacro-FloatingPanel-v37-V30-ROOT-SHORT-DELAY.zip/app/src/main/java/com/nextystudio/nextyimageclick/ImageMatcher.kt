package com.nextystudio.nextyimageclick

import android.graphics.Bitmap
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min

data class MatchResult(val found: Boolean, val x: Float = 0f, val y: Float = 0f, val score: Int = 0)

object ImageMatcher {
    fun find(screen: Bitmap, target: Bitmap, threshold: Int): MatchResult {
        if (screen.width < 1 || screen.height < 1 || target.width < 4 || target.height < 4) return MatchResult(false)
        val t = if (target.width > screen.width || target.height > screen.height) {
            val f = min(screen.width.toFloat() / target.width, screen.height.toFloat() / target.height)
            Bitmap.createScaledBitmap(target, max(4, (target.width*f).toInt()), max(4, (target.height*f).toInt()), true)
        } else target
        val tw=t.width; val th=t.height
        val tp=IntArray(tw*th); t.getPixels(tp,0,tw,0,0,tw,th)
        val sp=IntArray(screen.width*screen.height); screen.getPixels(sp,0,screen.width,0,0,screen.width,screen.height)
        val sx=min(36,tw); val sy=min(36,th)
        val samples=ArrayList<Int>(sx*sy)
        for (gy in 0 until sy) { val yy=if(sy==1)0 else gy*(th-1)/(sy-1); for(gx in 0 until sx){ val xx=if(sx==1)0 else gx*(tw-1)/(sx-1); samples.add(yy*tw+xx) } }
        var best=-1; var bx=0; var by=0
        val posStep=if(screen.width*screen.height>5_000_000)2 else 1
        val required=threshold.coerceIn(50,100)
        for(y in 0..(screen.height-th) step posStep){
            for(x in 0..(screen.width-tw) step posStep){
                var good=0
                for(idx in samples){
                    val yy=idx/tw; val xx=idx-yy*tw
                    val a=tp[idx]; val b=sp[(y+yy)*screen.width+x+xx]
                    val dr=abs(((a ushr 16) and 255)-((b ushr 16) and 255))
                    val dg=abs(((a ushr 8) and 255)-((b ushr 8) and 255))
                    val db=abs((a and 255)-(b and 255))
                    if(dr<=28 && dg<=28 && db<=28) good++
                }
                val score=(good*100)/samples.size
                if(score>best){best=score;bx=x;by=y}
                if(score>=required){ if(t!==target)t.recycle(); return MatchResult(true,bx+tw/2f,by+th/2f,score) }
            }
        }
        if(t!==target)t.recycle()
        return MatchResult(false,bx+tw/2f,by+th/2f,best.coerceAtLeast(0))
    }
}
