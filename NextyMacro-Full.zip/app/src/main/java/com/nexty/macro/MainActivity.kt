package com.nexty.macro

import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.widget.*
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {
    private lateinit var store: MacroStore
    private lateinit var list: LinearLayout
    private var macros = mutableListOf<Macro>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        store = MacroStore(this)
        macros = store.load()
        render()
    }

    private fun render() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(20, 20, 20, 20)
        }

        root.addView(TextView(this).apply {
            text = "Nexty Macro"
            textSize = 30f
        })
        root.addView(TextView(this).apply {
            text = "Macro automation • recorder • tap • swipe • text • repeat"
            textSize = 14f
            setPadding(0, 4, 0, 16)
        })

        root.addView(Button(this).apply {
            text = "1. AKTIFKAN ACCESSIBILITY"
            setOnClickListener {
                startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
            }
        })

        root.addView(Button(this).apply {
            text = "+ BUAT MACRO"
            setOnClickListener { createMacro() }
        })

        list = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
        }
        root.addView(ScrollView(this).apply { addView(list) },
            LinearLayout.LayoutParams(-1, 0, 1f))

        setContentView(root)
        refresh()
    }

    private fun refresh() {
        list.removeAllViews()
        if (macros.isEmpty()) {
            list.addView(TextView(this).apply {
                text = "Belum ada macro.\nTekan + BUAT MACRO."
                textSize = 18f
                setPadding(8, 24, 8, 24)
            })
        }
        macros.forEach { m ->
            val card = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                setPadding(8, 8, 8, 16)
            }
            card.addView(TextView(this).apply {
                text = "${m.name}\n${m.actions.size} aksi • repeat ${m.repeat}x"
                textSize = 18f
            })
            val row = LinearLayout(this)
            row.addView(Button(this).apply {
                text = "EDIT"
                setOnClickListener { editMacro(m) }
            })
            row.addView(Button(this).apply {
                text = "▶"
                setOnClickListener {
                    val s = NextyAccessibilityService.instance
                    if (s == null) toast("Aktifkan Accessibility dulu")
                    else s.play(m)
                }
            })
            row.addView(Button(this).apply {
                text = "■"
                setOnClickListener { NextyAccessibilityService.instance?.stop() }
            })
            row.addView(Button(this).apply {
                text = "DEL"
                setOnClickListener {
                    macros.remove(m)
                    store.save(macros)
                    refresh()
                }
            })
            card.addView(row)
            list.addView(card)
        }
    }

    private fun createMacro() {
        val input = EditText(this).apply { setText("Macro ${macros.size + 1}") }
        AlertDialog.Builder(this)
            .setTitle("Nama Macro")
            .setView(input)
            .setPositiveButton("Buat") { _, _ ->
                val m = Macro(System.currentTimeMillis(), input.text.toString())
                macros += m
                store.save(macros)
                editMacro(m)
            }
            .setNegativeButton("Batal", null)
            .show()
    }

    private fun editMacro(m: Macro) {
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(24, 8, 24, 8)
        }

        val repeat = EditText(this).apply {
            hint = "Repeat"
            setText(m.repeat.toString())
            inputType = 2
        }
        box.addView(TextView(this).apply { text = "Pengulangan" })
        box.addView(repeat)

        val actionsText = TextView(this).apply { textSize = 15f }
        box.addView(actionsText)

        fun redraw() {
            actionsText.text = m.actions.mapIndexed { i, a ->
                "${i + 1}. ${a.type.name} " +
                    if (a.type == ActionType.TAP) "(${a.x1.toInt()},${a.y1.toInt()})"
                    else if (a.type == ActionType.SWIPE)
                        "(${a.x1.toInt()},${a.y1.toInt()})→(${a.x2.toInt()},${a.y2.toInt()})"
                    else if (a.type == ActionType.TEXT) "\"${a.text}\""
                    else ""
            }.joinToString("\n").ifBlank { "Belum ada aksi" }
        }
        redraw()

        val add = LinearLayout(this)
        fun button(label: String, action: () -> Unit) =
            Button(this).apply { text = label; setOnClickListener { action() } }

        add.addView(button("TAP") { askTap(m, redraw) })
        add.addView(button("SWIPE") { askSwipe(m, redraw) })
        add.addView(button("DELAY") { askDelay(m, redraw) })
        add.addView(button("TEXT") { askText(m, redraw) })
        box.addView(add)

        val nav = LinearLayout(this)
        nav.addView(button("BACK") { m.actions += MacroAction(ActionType.BACK); redraw() })
        nav.addView(button("HOME") { m.actions += MacroAction(ActionType.HOME); redraw() })
        nav.addView(button("RECENTS") { m.actions += MacroAction(ActionType.RECENTS); redraw() })
        box.addView(nav)

        box.addView(button("RECORD TAP/SWIPE") {
            val s = NextyAccessibilityService.instance
            if (s == null) toast("Aktifkan Accessibility dulu")
            else {
                Toast.makeText(this, "Recorder aktif. STOP untuk selesai.", Toast.LENGTH_LONG).show()
                s.startRecorder(m) { redraw() }
            }
        })

        box.addView(button("HAPUS AKSI TERAKHIR") {
            if (m.actions.isNotEmpty()) m.actions.removeAt(m.actions.lastIndex)
            redraw()
        })

        AlertDialog.Builder(this)
            .setTitle(m.name)
            .setView(box)
            .setPositiveButton("SIMPAN") { _, _ ->
                m.repeat = repeat.text.toString().toIntOrNull()?.coerceAtLeast(1) ?: 1
                store.save(macros)
                refresh()
            }
            .setNegativeButton("TUTUP", null)
            .show()
    }

    private fun askTap(m: Macro, redraw: () -> Unit) {
        val box = coordsBox()
        AlertDialog.Builder(this).setTitle("Tap")
            .setView(box.view)
            .setPositiveButton("Tambah") { _, _ ->
                m.actions += MacroAction(ActionType.TAP, box.x(), box.y())
                redraw()
            }.setNegativeButton("Batal", null).show()
    }

    private fun askSwipe(m: Macro, redraw: () -> Unit) {
        val box = swipeBox()
        AlertDialog.Builder(this).setTitle("Swipe")
            .setView(box.view)
            .setPositiveButton("Tambah") { _, _ ->
                m.actions += MacroAction(
                    ActionType.SWIPE, box.x1(), box.y1(), box.x2(), box.y2(),
                    box.duration()
                )
                redraw()
            }.setNegativeButton("Batal", null).show()
    }

    private fun askDelay(m: Macro, redraw: () -> Unit) {
        val e = EditText(this).apply { setText("1000"); inputType = 2 }
        AlertDialog.Builder(this).setTitle("Delay ms").setView(e)
            .setPositiveButton("Tambah") { _, _ ->
                m.actions += MacroAction(ActionType.DELAY, duration = e.text.toString().toLongOrNull() ?: 1000)
                redraw()
            }.setNegativeButton("Batal", null).show()
    }

    private fun askText(m: Macro, redraw: () -> Unit) {
        val e = EditText(this).apply { hint = "Teks yang akan diisi" }
        AlertDialog.Builder(this).setTitle("Text").setView(e)
            .setPositiveButton("Tambah") { _, _ ->
                m.actions += MacroAction(ActionType.TEXT, text = e.text.toString())
                redraw()
            }.setNegativeButton("Batal", null).show()
    }

    private fun coordsBox(): CoordBox {
        val x = EditText(this).apply { hint = "X"; inputType = 2 }
        val y = EditText(this).apply { hint = "Y"; inputType = 2 }
        val l = LinearLayout(this)
        l.addView(x); l.addView(y)
        return CoordBox(l, x, y)
    }

    private fun swipeBox(): SwipeBox {
        val es = (1..5).map { EditText(this).apply { inputType = 2 } }
        es[0].hint = "X1"; es[1].hint = "Y1"; es[2].hint = "X2"; es[3].hint = "Y2"; es[4].apply { hint = "Durasi ms"; setText("400") }
        val l = LinearLayout(this)
        es.forEach { l.addView(it) }
        return SwipeBox(l, es)
    }

    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_SHORT).show()

    data class CoordBox(val view: LinearLayout, val ex: EditText, val ey: EditText) {
        fun x() = ex.text.toString().toFloatOrNull() ?: 0f
        fun y() = ey.text.toString().toFloatOrNull() ?: 0f
    }

    data class SwipeBox(val view: LinearLayout, val e: List<EditText>) {
        fun x1() = e[0].text.toString().toFloatOrNull() ?: 0f
        fun y1() = e[1].text.toString().toFloatOrNull() ?: 0f
        fun x2() = e[2].text.toString().toFloatOrNull() ?: 0f
        fun y2() = e[3].text.toString().toFloatOrNull() ?: 0f
        fun duration() = e[4].text.toString().toLongOrNull() ?: 400L
    }
}
